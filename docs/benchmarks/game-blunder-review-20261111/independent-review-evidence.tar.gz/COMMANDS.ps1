# Run from the Shogi-App repo working directory. Use a new output directory.
$env:TEMP=(Resolve-Path '.tmp-tests/review-20261111').Path
$env:TMP=$env:TEMP
$env:NODE_COMPILE_CACHE=Join-Path $env:TEMP 'independent-node-cache'
$repo=(Get-Location).Path
$output=[IO.Path]::GetFullPath((Join-Path $repo '../.shogi-independent-review-20261111/NEW_RESULTS'))
node --import tsx ../.shogi-independent-review-20261111/independent.mjs run 1edc169cc9ff27b7c77e825e95b893e5b0252ed1 $repo docs/benchmarks/game-blunder-review-20261111/fixed-run/observations.jsonl $output
python ../.shogi-independent-review-20261111/audit.py

# The recorded v2 command used results-1edc169-v2 instead of NEW_RESULTS.
# Official stdout/stderr is independent-run-v2.log.
# audit.json is a fresh read of the old hashes, Git blobs, sources and legacy aggregate.
node ../.shogi-independent-review-20261111/verify-results.mjs $output
