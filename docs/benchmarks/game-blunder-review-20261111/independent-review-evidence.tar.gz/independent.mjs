import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {execFileSync,spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';

const [mode,expectedHead,repo,input,output]=process.argv.slice(2);
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
if(mode==='--one') {
  const {summarizeV4}=await import(pathToFileURL(resolve(repo,'scripts/summarize-game-blunders.ts')).href);
  try {
    const s=summarizeV4(readFileSync(input,'utf8'));
    console.log(JSON.stringify({decision:'aggregated',roots:s.fixed.rootReproducibility.filter(r=>r.reproducible).length,
      invalid:s.fixed.invalidObservations,hashSource:s.fixed.rootPositionHashSource,groups:s.fixed.groups.map(g=>({
        id:g.id,legalReplies:g.legalReplies,legalCaptures:g.legalCaptures,
        comparable:g.conditions?.filter(c=>c.reproducible).length,
        delta:g.conditions?.map(c=>c.judgment.delta)
      }))}));
  } catch(error) {
    console.log(JSON.stringify({decision:'rejected',reason:error.message}));
    process.exitCode=1;
  }
} else {
  const actualHead=execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim();
  const codePaths=['scripts','src','package.json','package-lock.json','tsconfig.json','vite.config.ts','.github'];
  execFileSync('git',['merge-base','--is-ancestor',expectedHead,actualHead],{cwd:repo});
  execFileSync('git',['diff','--exit-code',expectedHead,actualHead,'--',...codePaths],{cwd:repo});
  const {json,repeatKey,restoreInvestigationPositions}=await import(pathToFileURL(resolve(repo,'scripts/benchmarks/gameBlunderInvestigation.ts')).href);
  const {getLegalActions}=await import(pathToFileURL(resolve(repo,'src/domain/shogi/legalActions.ts')).href);
  const {apply}=await import(pathToFileURL(resolve(repo,'scripts/benchmarks/gameBlunderPilot.ts')).href);
  const {evaluateSearchPositionBreakdown}=await import(pathToFileURL(resolve(repo,'src/domain/shogi/twoPlyMinimaxAi.ts')).href);
  const {isPlayerInCheck}=await import(pathToFileURL(resolve(repo,'src/domain/shogi/checkmate.ts')).href);
  const sourcePaths=['scripts/summarize-game-blunders.ts','scripts/benchmarks/gameBlunderInvestigation.ts'];
  const sourceHashes=()=>Object.fromEntries(sourcePaths.map(p=>[p,sha(readFileSync(join(repo,p)))]));
  const beforeSources=sourceHashes();
  const startStatus=execFileSync('git',['status','--porcelain=v1','--untracked-files=no'],{cwd:repo,encoding:'utf8'}).trim();
  const original=readFileSync(input,'utf8');
  const parse=()=>original.trim().split('\n').map(JSON.parse);
  const plan=parse()[0];
  const positions=restoreInvestigationPositions(plan.paths,plan.before,new Set(plan.selection));
  const first=plan.selection[0];
  const group=(rows,id=first)=>rows.filter(r=>r.type==='root-fixed'&&r.id===id);
  const refresh=r=>{r.repeatKey=repeatKey(r);};
  const alter=fn=>rows=>group(rows).forEach(fn);
  let quietPosition;
  for(const id of plan.selection) {
    const r=group(parse(),id)[0],c=positions.get(id),child=apply(c.state,r.result.selectedAction);
    if(child.status==='ended'||isPlayerInCheck(child,child.turn))continue;
    const quiet=getLegalActions(child).find(a=>child.squares[a.to.row][a.to.col].piece===null);
    if(quiet) {quietPosition={id,r,c,quiet};break;}
  }
  assert.ok(quietPosition);
  let horizonPosition;
  for(const id of plan.selection) {
    const r=group(parse(),id)[0],c=positions.get(id);
    let state=c.state;
    const pv=[...r.result.principalVariation];
    for(const a of pv)state=apply(state,a);
    const extend=(state,pv)=>{
      if(pv.length===3) {
        const breakdown=evaluateSearchPositionBreakdown(state,c.state.turn,{pieceSafetyMode:c.mode});
        return Number.isFinite(breakdown.total)?{pv,breakdown}:null;
      }
      const captures=getLegalActions(state).filter(a=>{
        const target=state.squares[a.to.row][a.to.col].piece;
        return a.kind==='move'&&target!==null&&target.player!==a.player;
      });
      for(const a of captures) {
        const found=extend(apply(state,a),[...pv,a]);
        if(found)return found;
      }
      return null;
    };
    const found=extend(state,pv);
    if(found) {horizonPosition={id,c,...found};break;}
  }
  assert.ok(horizonPosition,'capture-only extension to three plies required for an isolated horizon counterexample');
  const cases=[
    {name:'normal',change:'Untouched final schema 3 evidence',mutate:()=>{}},
    {name:'finite-score-and-total',change:'Change both finite selectedEvaluation and breakdown.total by +17 in both root repetitions, regenerate keys',mutate:alter(r=>{
      r.result.selectedEvaluation+=17;r.result.evaluationBreakdown.total+=17;refresh(r);
    })},
    {name:'coherent-fake-components',change:'Change both finite score and material component and total by +17 in both root repetitions, regenerate keys',mutate:alter(r=>{
      r.result.selectedEvaluation+=17;r.result.evaluationBreakdown.total+=17;r.result.evaluationBreakdown.material+=17;refresh(r);
    })},
    {name:'normal-node-count',change:'Change observed normal enter count in both root repetitions while preserving result counts, regenerate keys',mutate:alter(r=>{
      r.nodes.normal=r.nodes.normal===0?1:r.nodes.normal-1;refresh(r);
    })},
    {name:'q-node-count',change:'Change observed q enter count in both root repetitions while preserving result counts, regenerate keys',mutate:alter(r=>{
      r.nodes.quiescence=r.nodes.quiescence===0?1:r.nodes.quiescence-1;refresh(r);
    })},
    {name:'unused-negative-counters',scope:'additional-statistics',change:'Set unused cutoff and skipped-action result counters to -1 in both root repetitions',mutate:alter(r=>{
      for(const k of ['cutoffCount','skippedActionCount','quiescenceCutoffCount','quiescenceSkippedActionCount'])r.result[k]=-1;
    })},
    {name:'unused-nonfinite-counters',scope:'additional-statistics',change:'Set unused cutoff result counter and elapsedMilliseconds to tagged nonfinite values',mutate:alter(r=>{
      r.result.cutoffCount=NaN;r.result.elapsedMilliseconds=Infinity;
    })},
    ...['positionHash','mode','condition','budget'].map(field=>({
      name:'missing-runtime-'+field,
      change:'Delete required runtime '+field+' from schema 3 root rep1 while preserving result and repeatKey',
      mutate:rows=>{delete group(rows)[1][field];}
    })),
    {name:'schema-downgrade',change:'Demote schema 3 to2 and delete root and probe runtime identity fields',mutate:rows=>{
      rows[0].schema=2;
      for(const r of rows) {
        if(r.type==='root-fixed')delete r.positionHash;
        if(r.type==='probe-control')for(const k of ['condition','mode','budget','positionHash'])delete r[k];
      }
    }},
    {name:'reply-capture-spoof',change:'Replace saved actual candidate replies/captures/branches with empty arrays',mutate:rows=>{
      const c=rows.find(r=>r.type==='candidates');c.actual.replies=[];c.actual.captures=[];c.actual.branches=[];
    }},
    {name:'overlong-legal-pv',change:'Extend an existing root PV to3 plies only through legal captures, evaluate new leaf and update both repeats and keys',mutate:rows=>{
      const {id,pv,breakdown}=horizonPosition;
      for(const r of group(rows,id)) {
        r.result.principalVariation=pv;
        r.result.evaluationBreakdown=breakdown;
        r.result.selectedEvaluation=breakdown.total;refresh(r);
      }
    }},
    {name:'quiet-q-suffix',change:'Replace q suffix by a legal quiet move in a nonchecked position, recompute real leaf evaluation and keys',mutate:rows=>{
      const {id,c,quiet}=quietPosition;
      for(const r of group(rows,id)) {
        const child=apply(c.state,r.result.selectedAction),leaf=apply(child,quiet);
        r.result.principalVariation=[r.result.selectedAction,quiet];
        r.result.evaluationBreakdown=evaluateSearchPositionBreakdown(leaf,c.state.turn,{pieceSafetyMode:c.mode});
        r.result.selectedEvaluation=r.result.evaluationBreakdown.total;refresh(r);
      }
    }}
  ];
  mkdirSync(output,{recursive:true});
  const results=[];
  for(const {name,scope,change,mutate} of cases) {
    const rows=parse();mutate(rows);
    const raw=name==='normal'?original:rows.map(json).join('\n')+'\n';
    const file=join(output,name+'.jsonl');
    writeFileSync(file,raw,{flag:'wx'});
    const began=performance.now();
    const run=spawnSync(process.execPath,['--import','tsx',process.argv[1],'--one',expectedHead,repo,file],{encoding:'utf8',cwd:repo});
    assert.ok(!run.error,run.error?.message);
    assert.ok(run.stdout,run.stderr);
    const result=JSON.parse(run.stdout);
    const entry={name,scope,change,inputSha256:sha(raw),exitCode:run.status,seconds:(performance.now()-began)/1000,...result};
    results.push(entry);console.log(name,run.status,result.decision,result.roots,result.invalid?.count);
  }
  const endHead=execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim();
  execFileSync('git',['diff','--exit-code',expectedHead,endHead,'--',...codePaths],{cwd:repo});
  assert.deepEqual(sourceHashes(),beforeSources);
  writeFileSync(join(output,'results.json'),JSON.stringify({recordedAt:new Date().toISOString(),sourceHead:expectedHead,headAtStart:actualHead,headAtEnd:endHead,source:input,sourceHash:sha(original),node:process.version,platform:process.platform,
    sourceHashes:beforeSources,trackedStatusAtStart:startStatus,trackedStatusAtEnd:execFileSync('git',['status','--porcelain=v1','--untracked-files=no'],{cwd:repo,encoding:'utf8'}).trim(),temp:process.env.TEMP,cache:process.env.NODE_COMPILE_CACHE??null,
    results},null,2)+'\n',{flag:'wx'});
}
