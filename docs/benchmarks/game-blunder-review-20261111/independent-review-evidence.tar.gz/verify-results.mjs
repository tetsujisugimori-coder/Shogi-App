import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';

const result=JSON.parse(readFileSync(resolve(process.argv[2],'results.json'),'utf8'));
assert.equal(result.results.length,15);
const normal=result.results.find(r=>r.name==='normal');
assert.equal(normal.exitCode,0);
assert.equal(normal.roots,24);
assert.equal(normal.invalid.count,0);
assert.equal(normal.hashSource,'recorded-and-journal-verified');
assert.equal(normal.groups.length,4);
assert.ok(normal.groups.every(g=>g.comparable===4));

const rejected={
  'missing-runtime-positionHash':'fixed position hash',
  'missing-runtime-mode':'fixed mode',
  'missing-runtime-condition':'fixed condition',
  'missing-runtime-budget':'fixed budget',
  'schema-downgrade':'schema does not match runner provenance',
  'reply-capture-spoof':'candidate reply or exchange metadata mismatch'
};
const excluded={
  'finite-score-and-total':'pv-evaluation-mismatch',
  'coherent-fake-components':'pv-evaluation-mismatch',
  'normal-node-count':'inconsistent-node-counts',
  'q-node-count':'inconsistent-node-counts',
  'unused-negative-counters':'invalid-result-statistics',
  'unused-nonfinite-counters':'invalid-result-statistics',
  'overlong-legal-pv':'pv-exceeds-search-horizon',
  'quiet-q-suffix':'non-tactical-quiescence-pv'
};
for(const [name,prefix] of Object.entries(rejected)) {
  const row=result.results.find(r=>r.name===name);
  assert.equal(row.exitCode,1,name);
  assert.equal(row.decision,'rejected',name);
  assert.ok(row.reason.startsWith(prefix),name);
}
for(const [name,reason] of Object.entries(excluded)) {
  const row=result.results.find(r=>r.name===name);
  assert.equal(row.exitCode,0,name);
  assert.equal(row.roots,23,name);
  assert.equal(row.invalid.count,2,name);
  assert.deepEqual(row.invalid.byReason,{[reason]:2},name);
  assert.deepEqual(row.invalid.rows.map(r=>r.rep).sort(),[0,1],name);
  assert.equal(new Set(row.invalid.rows.map(r=>r.id)).size,1,name);
}
console.log('PASS 1 normal control, 6 process rejections, 8 result exclusions with exact causes');
