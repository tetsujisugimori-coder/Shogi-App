import gzip
import hashlib
import json
import pathlib
import subprocess
from datetime import datetime, timezone

root=pathlib.Path.cwd()
out=(root/'../.shogi-independent-review-20261111').resolve()
evidence=root/'docs/benchmarks/game-blunder-review-20261111'
source_head='1edc169cc9ff27b7c77e825e95b893e5b0252ed1'
baseline='e1ccb1a2412e7faa86c2c1f60fdad1dca154023a'
sha=lambda data:hashlib.sha256(data).hexdigest()
blob=lambda head,path:subprocess.check_output(['git','show',head+':'+path],cwd=root)
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
before=read(evidence/'originals-before.json')
after=read(evidence/'originals-after.json')
current=[{'path':r['path'],'sha256':sha((root/r['path']).read_bytes())} for r in before]
recorded_after=[{'path':r['path'],'sha256':r['currentSha256']} for r in after['files']]
assert before==recorded_after==current
plan=json.loads((evidence/'fixed-run/observations.jsonl').open(encoding='utf8').readline())
assert plan['baseHead']==source_head
sources=[]
for path,expected in plan['sourceHashes'].items():
    actual=(root/path).read_bytes()
    committed=blob(source_head,path)
    sources.append({'path':path,'rawHashMatchesPlan':sha(actual)==expected,
                    'canonicalLFMatchesFixedGitBlob':actual.replace(b'\r\n',b'\n')==committed.replace(b'\r\n',b'\n')})
assert all(r['rawHashMatchesPlan'] and r['canonicalLFMatchesFixedGitBlob'] for r in sources)
raw=[]
for r in read(evidence/'legacy-raw-log-verification.json')['logs']:
    actual=(root/r['path']).read_bytes()
    archived=blob(baseline,r['archivedPath'])
    raw.append({'path':r['path'],'currentSha256':sha(actual),'archiveSha256':sha(archived),
                'matchesArchivedDecompressedBytes':actual==gzip.decompress(archived)})
assert all(r['matchesArchivedDecompressedBytes'] for r in raw)
snapshots=[]
for path in ['scripts/benchmarks/gameBlunderInvestigation.ts','scripts/benchmarks/gameBlunderPilot.ts',
             'scripts/investigate-game-blunders.ts','scripts/summarize-game-blunders.ts']:
    archived=gzip.decompress((evidence/'baseline-sources'/(pathlib.Path(path).name+'.gz')).read_bytes())
    snapshots.append({'path':path,'matchesBaselineGitBlob':archived==blob(baseline,path)})
assert all(r['matchesBaselineGitBlob'] for r in snapshots)
old=read(root/'docs/benchmarks/game-blunder-investigation-v4-20261105/summary.json')
rebuilt=read(evidence/'legacy-reaggregated-fixed.json')
assert rebuilt['fixed'].pop('rootPositionHashSource')=='journal-reconstructed'
assert rebuilt['fixed'].pop('invalidObservations')['count']==0
assert old==rebuilt
protected=['src/domain','src/types','package.json','package-lock.json','vite.config.ts','.github/workflows']
protected_diff=subprocess.check_output(['git','diff',baseline,'HEAD','--',*protected],cwd=root,encoding='utf8')
assert not protected_diff
result={'recordedAt':datetime.now(timezone.utc).isoformat(),'sourceHead':source_head,
        'headAtAudit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,encoding='utf8').strip(),
        'originalFiles':len(before),'originalHashesAllEqual':True,'currentOriginals':current,
        'sourceFiles':len(sources),'sourceFilesAllVerified':True,'sources':sources,
        'legacyRawLogs':raw,'baselineSnapshots':snapshots,'legacyReaggregationMatchesSavedSummary':True,
        'protectedPaths':protected,'protectedDiff':protected_diff}
(out/'audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'originals':len(before),'sources':len(sources),'rawLogs':len(raw),'baselineSnapshots':len(snapshots),
                  'legacyAggregateEqual':True,'protectedPathsUnchanged':True}))
