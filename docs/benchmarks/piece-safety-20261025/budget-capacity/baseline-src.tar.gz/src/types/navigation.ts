export type AppView = 'shogi';
