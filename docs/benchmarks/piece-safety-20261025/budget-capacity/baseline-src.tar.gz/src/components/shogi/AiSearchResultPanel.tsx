import type { SearchEvaluationPresetId } from '../../domain/shogi/searchEvaluationPresets';
import type { PresetTimeLimitedSearchResult } from '../../workers/timeLimitedIterativeDeepeningAlphaBetaWorkerProtocol';
import type {
  TwoPlyMinimaxSearchResult,
} from '../../domain/shogi';

import type { Player } from '../../types/shogi';
import { formatSenteEvaluation } from './searchEvaluationDisplay';
import { getGameResultDisplay } from './gameResultDisplay';

export type AiSearchDisplay =
  | {
      kind: 'two-ply';
      perspective: Player;
      result: TwoPlyMinimaxSearchResult & { readonly evaluationPresetId: SearchEvaluationPresetId };
      selectedNotation: string;
      candidateNotations: readonly string[];
    }
  | {
      kind: 'time-limited-worker';
      perspective: Player;
      result: PresetTimeLimitedSearchResult;
      selectedNotation: string;
      principalVariationNotations: readonly string[];
    };

interface AiSearchResultPanelProps {
  search: AiSearchDisplay;
}

/** A compact presentation of the latest synchronous or Worker AI search. */
export function AiSearchResultPanel({ search }: AiSearchResultPanelProps) {
  if (search.kind === 'time-limited-worker') {
    const { result } = search;
    const quiescenceLabel = result.quiescenceMaxTacticalDepth === null
      ? '無効' : `追加${result.quiescenceMaxTacticalDepth}手`;
    return (
      <section
        aria-labelledby="ai-search-result-title"
        className="w-full min-w-0 rounded border border-sky-800/70 bg-sky-950/30 p-3 shadow-inner xl:max-w-sm"
      >
        <h2 id="ai-search-result-title" className="font-serif text-sm tracking-[0.12em] text-sky-100">
          AI思考結果
        </h2>
        <p className="mt-1 text-xs text-stone-300">時間制限付き反復深化αβ探索</p>
        {result.resultSource === 'partial-root' && <p className="mt-1 text-xs text-stone-300">選択候補の評価・PVです。全合法手の比較は未完了です。</p>}
        <dl className="mt-2 grid grid-cols-[minmax(0,2fr)_minmax(0,1fr)] gap-x-3 gap-y-1 text-xs">
          <dt className="text-stone-400">完了深さ</dt>
          <dd className="text-sky-100">{result.completedDepth}</dd>
          <dt className="text-stone-400">着手の出所</dt>
          <dd className="text-sky-100">{result.resultSource === 'ended-position' ? '終局済み' : result.resultSource === 'no-legal-actions' ? '合法手なし' : result.resultSource === 'fallback' ? '合法手 fallback' : result.resultSource === 'partial-root' ? '部分探索・深さ1未完了' : '完了した探索'}</dd>
          {result.resultSource === 'ended-position' && result.terminalResult && <>
            <dt className="text-stone-400">終局結果</dt>
            <dd className="text-sky-100">{getGameResultDisplay(result.terminalResult).panelText}</dd>
          </>}
          {result.resultSource === 'partial-root' && result.partialRoot && <>
            <dt className="text-stone-400">期限内確定候補／合法手数</dt>
            <dd className="text-sky-100">{result.partialRoot.completedRootCandidateCount} / {result.rootLegalActionCount}</dd>
            <dt className="text-stone-400">exact候補数</dt>
            <dd className="text-sky-100">{result.partialRoot.exactRootCandidateCount}</dd>
          </>}
          <dt className="text-stone-400">指定最大深さ</dt>
          <dd className="text-sky-100">{result.requestedMaxDepth}</dd>
          <dt className="text-stone-400">API全体の経過時間</dt>
          <dd className="text-sky-100">{result.elapsedMilliseconds.toFixed(2)} ms</dd>
          <dt className="text-stone-400">静止探索</dt>
          <dd className="text-sky-100">{quiescenceLabel}</dd>
          <dt className="text-stone-400">最深完了反復の調査局面数</dt>
          <dd className="text-sky-100">{result.visitedPositionCount}</dd>
          <dt className="text-stone-400">最深完了反復の枝刈り回数</dt>
          <dd className="text-sky-100">{result.cutoffCount}</dd>
          <dt className="text-stone-400">最深完了反復の未調査候補手数</dt>
          <dd className="text-sky-100">{result.skippedActionCount}</dd>
          <dt className="text-stone-400">全完了反復合計の調査局面数</dt>
          <dd className="text-sky-100">{result.totalVisitedPositionCount}</dd>
          <dt className="text-stone-400">全完了反復合計の枝刈り回数</dt>
          <dd className="text-sky-100">{result.totalCutoffCount}</dd>
          <dt className="text-stone-400">全完了反復合計の未調査候補手数</dt>
          <dd className="text-sky-100">{result.totalSkippedActionCount}</dd>
        </dl>
        <div className="mt-3 border-t border-sky-900/80 pt-2">
          <h3 className="text-xs font-medium text-stone-300">静止探索の量（通常探索とは別）</h3>
          <dl className="mt-1 grid grid-cols-[minmax(0,2fr)_minmax(0,1fr)] gap-x-3 gap-y-1 text-xs">
            <dt className="text-stone-400">最深完了反復の静止探索葉数</dt>
            <dd className="text-sky-100">{result.quiescenceLeafCount}</dd>
            <dt className="text-stone-400">最深完了反復の静止探索調査局面数</dt>
            <dd className="text-sky-100">{result.quiescenceVisitedPositionCount}</dd>
            <dt className="text-stone-400">最深完了反復の静止探索枝刈り回数</dt>
            <dd className="text-sky-100">{result.quiescenceCutoffCount}</dd>
            <dt className="text-stone-400">最深完了反復の静止探索未調査候補手数</dt>
            <dd className="text-sky-100">{result.quiescenceSkippedActionCount}</dd>
            <dt className="text-stone-400">全完了反復合計の静止探索葉数</dt>
            <dd className="text-sky-100">{result.totalQuiescenceLeafCount}</dd>
            <dt className="text-stone-400">全完了反復合計の静止探索調査局面数</dt>
            <dd className="text-sky-100">{result.totalQuiescenceVisitedPositionCount}</dd>
            <dt className="text-stone-400">全完了反復合計の静止探索枝刈り回数</dt>
            <dd className="text-sky-100">{result.totalQuiescenceCutoffCount}</dd>
            <dt className="text-stone-400">全完了反復合計の静止探索未調査候補手数</dt>
            <dd className="text-sky-100">{result.totalQuiescenceSkippedActionCount}</dd>
          </dl>
        </div>
      </section>
    );
  }

  const { result, candidateNotations } = search;
  return (
    <section
      aria-labelledby="ai-search-result-title"
      className="w-full min-w-0 rounded border border-violet-800/70 bg-violet-950/30 p-3 shadow-inner xl:max-w-sm"
    >
      <h2 id="ai-search-result-title" className="font-serif text-sm tracking-[0.12em] text-violet-100">
        AI思考結果
      </h2>
      <dl className="mt-2 grid grid-cols-[minmax(0,2fr)_minmax(0,1fr)] gap-x-3 gap-y-1 text-xs">
        <dt className="text-stone-400">合法手数</dt>
        <dd className="text-violet-100">{result.rootLegalActionCount}</dd>
        <dt className="text-stone-400">調査局面数</dt>
        <dd className="text-violet-100">{result.visitedPositionCount}</dd>
        <dt className="text-stone-400">読みの深さ</dt>
        <dd className="text-violet-100">{result.depth}</dd>
        <dt className="text-stone-400">経過時間</dt>
        <dd className="text-violet-100">{result.elapsedMilliseconds.toFixed(2)} ms</dd>
      </dl>
      <div className="mt-3 border-t border-violet-900/80 pt-2">
        <h3 className="text-xs font-medium text-stone-300">上位候補手</h3>
        <p className="mt-1 text-xs text-stone-400">先手基準：＋は先手有利、−は後手有利</p>
        <ol className="mt-1 space-y-1 text-xs text-violet-100">
          {result.topCandidates.map((candidate, index) => (
            <li key={`${candidateNotations[index]}-${index}`} className="flex flex-wrap justify-between gap-3 break-words">
              <span>{candidateNotations[index]}</span>
              <span>先手 {formatSenteEvaluation(candidate.evaluation, search.perspective)}</span>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
