/**
 * Shogi Move Generation & Legality Engine
 * Pure functions to compute pseudo-legal moves, filter out illegal moves (王手放置・自殺手・行き所のない駒),
 * and produce strictly legal moves according to standard Shogi rules.
 */

import { BoardSquare, Piece, Player } from '../../types/shogi';
import { Coordinate, isWithinBoard } from './coordinates';
import {
  getPieceAttackPattern,
  isKingInCheck,
  isKingInCheckProfiled,
} from './attacks';
import { isPromotionRequired } from './promotion';
import type { ActionValidationProbe } from './actionValidationDiagnostics';
import type { SearchDiagnostics } from './searchDiagnostics';

/**
 * Checks if a move results in a piece having no legal forward moves ("行き所のない駒").
 * Applies only to unpromoted Pawns, Lances (cannot reach rank 1 for Sente / rank 9 for Gote)
 * and Knights (cannot reach ranks 1-2 for Sente / ranks 8-9 for Gote).
 */
export function isDeadPieceMove(piece: Piece, to: Coordinate): boolean {
  return isPromotionRequired(piece, to);
}

/**
 * Generates pseudo-legal moves for a piece based on geometric movement,
 * board boundaries, piece collision (stopping at obstacles), and own-piece blocking.
 * Excludes capturing opponent King directly.
 */
export function getPseudoLegalMoves(
  squares: BoardSquare[][],
  from: Coordinate,
  piece: Piece
): Coordinate[] {
  const candidates: Coordinate[] = [];
  const pattern = getPieceAttackPattern(piece);

  // Check single step moves
  for (const [dr, dc] of pattern.stepOffsets) {
    const targetRow = from.row + dr;
    const targetCol = from.col + dc;

    if (!isWithinBoard(targetRow, targetCol)) continue;

    const targetSquare = squares[targetRow][targetCol];
    if (!targetSquare.piece) {
      candidates.push({ row: targetRow, col: targetCol });
    } else if (targetSquare.piece.player !== piece.player) {
      // Opponent piece - can capture unless King
      if (targetSquare.piece.type !== 'king') {
        candidates.push({ row: targetRow, col: targetCol });
      }
    }
  }

  // Check sliding ray moves
  for (const [dr, dc] of pattern.rayDirections) {
    let currRow = from.row + dr;
    let currCol = from.col + dc;

    while (isWithinBoard(currRow, currCol)) {
      const targetSquare = squares[currRow][currCol];

      if (!targetSquare.piece) {
        candidates.push({ row: currRow, col: currCol });
      } else {
        if (targetSquare.piece.player !== piece.player) {
          // Can capture opponent piece unless King, then stop ray
          if (targetSquare.piece.type !== 'king') {
            candidates.push({ row: currRow, col: currCol });
          }
        }
        break; // Blocked by any piece
      }

      currRow += dr;
      currCol += dc;
    }
  }

  return candidates;
}

/**
 * Creates a lightweight simulated 9x9 board with the move applied, for checking king safety.
 */
export function simulateMoveSquares(
  squares: BoardSquare[][],
  from: Coordinate,
  to: Coordinate
): BoardSquare[][] {
  const nextSquares = squares.map((row) =>
    row.map((sq) => ({
      ...sq,
      piece: sq.piece ? { ...sq.piece } : null,
    }))
  );

  if (!isWithinBoard(from.row, from.col) || !isWithinBoard(to.row, to.col)) {
    return nextSquares;
  }

  const movingPiece = nextSquares[from.row][from.col].piece;
  if (!movingPiece) return nextSquares;

  nextSquares[from.row][from.col].piece = null;
  nextSquares[to.row][to.col].piece = { ...movingPiece };

  return nextSquares;
}

/** King-safety readers only need the two changed squares. Never expose this shared copy. */
function simulateMoveSquaresForKingSafety(
  squares: BoardSquare[][],
  from: Coordinate,
  to: Coordinate
): BoardSquare[][] {
  const nextSquares = squares.slice();
  nextSquares[from.row] = squares[from.row].slice();
  if (to.row !== from.row) nextSquares[to.row] = squares[to.row].slice();
  nextSquares[from.row][from.col] = { ...squares[from.row][from.col], piece: null };
  nextSquares[to.row][to.col] = {
    ...squares[to.row][to.col], piece: squares[from.row][from.col].piece,
  };
  return nextSquares;
}

/**
 * Computes strictly legal moves for a piece at `from`.
 * Validates:
 * 1. Piece exists and belongs to current turn (if specified).
 * 2. Basic geometric movements.
 * 3. Does NOT leave own King in check (resolves checks, prevents self-check & pinned piece violations).
 * Mandatory-promotion destinations remain legal candidates; executeMove validates the choice.
 */
export function getLegalMoves(
  squares: BoardSquare[][],
  from: Coordinate | null | undefined,
  currentTurn?: Player,
  qDiagnostics?: SearchDiagnostics,
  probe?: ActionValidationProbe
): Coordinate[] {
  if (!from || !isWithinBoard(from.row, from.col)) {
    return [];
  }

  const square = squares[from.row][from.col];
  if (!square || !square.piece) {
    return [];
  }

  const piece = square.piece;
  if (currentTurn && piece.player !== currentTurn) {
    return [];
  }

  if (qDiagnostics || probe) {
    const generate = () => getPseudoLegalMoves(squares, from, piece);
    const generateMeasured = () => qDiagnostics
      ? qDiagnostics.measure('q-board-pseudo', generate) : generate();
    const pseudoMoves = probe ? probe.measure('pseudo', generateMeasured) : generateMeasured();
    if (qDiagnostics) qDiagnostics.qLegalCounts.boardPseudo += pseudoMoves.length;
    const legalMoves: Coordinate[] = [];
    for (const dest of pseudoMoves) {
      const validate = () => {
        const simulate = () => simulateMoveSquaresForKingSafety(squares, from, dest);
        const simulateMeasured = () => qDiagnostics
          ? qDiagnostics.measure('q-board-simulate', simulate) : simulate();
        const simulatedSquares = probe ? probe.measure('board-setup', simulateMeasured) : simulateMeasured();
        const check = () => qDiagnostics?.checkInternals
          ? isKingInCheckProfiled(simulatedSquares, piece.player, qDiagnostics.checkInternals.board)
          : isKingInCheck(simulatedSquares, piece.player);
        const checkMeasured = () => qDiagnostics ? qDiagnostics.measure('q-board-own-check', check) : check();
        return !(probe ? probe.measure('own-check', checkMeasured) : checkMeasured());
      };
      if (probe ? probe.measure('validation', validate) : validate()) legalMoves.push(dest);
    }
    if (qDiagnostics) qDiagnostics.qLegalCounts.boardLegal += legalMoves.length;
    return legalMoves;
  }

  const pseudoMoves = getPseudoLegalMoves(squares, from, piece);
  const legalMoves: Coordinate[] = [];

  for (const dest of pseudoMoves) {
    // Simulate move and check if own king is left in check
    const simulatedSquares = simulateMoveSquaresForKingSafety(squares, from, dest);
    if (isKingInCheck(simulatedSquares, piece.player)) {
      continue;
    }

    legalMoves.push(dest);
  }

  return legalMoves;
}

/** Exact existence query using the same candidates and king-safety simulation.
 * No legal destination list is materialized and validation stops at the first.
 */
export function hasLegalMove(
  squares: BoardSquare[][],
  from: Coordinate,
  currentTurn?: Player
): boolean {
  if (!isWithinBoard(from.row, from.col)) return false;
  const piece = squares[from.row]?.[from.col]?.piece;
  if (!piece || (currentTurn && piece.player !== currentTurn)) return false;
  return getPseudoLegalMoves(squares, from, piece).some(to =>
    !isKingInCheck(simulateMoveSquaresForKingSafety(squares, from, to), piece.player));
}

/** Alias for backward-compatibility with UI components. */
export function getMoveCandidates(
  squares: BoardSquare[][],
  from: Coordinate | null | undefined,
  currentTurn?: Player
): Coordinate[] {
  return getLegalMoves(squares, from, currentTurn);
}
