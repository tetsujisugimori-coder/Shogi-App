import { describe, expect, it } from 'vitest';
import {
  cloneBoardSquares,
  cloneBoardState,
  analyzeAlphaBetaSearch,
  analyzeIterativeDeepeningAlphaBetaSearch,
  analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch,
  analyzeTwoPlyAlphaBetaSearch,
  analyzeTwoPlyMinimaxSearch,
  areLegalActionsEqual,
  createPositionKey,
  DEFAULT_KING_SAFETY_EVALUATION_WEIGHTS,
  evaluateKingSafety,
  evaluateMaterial,
  evaluatePieceSquarePosition,
  evaluateSearchPosition,
  evaluateSearchPositionBreakdown,
  evaluateUndefendedPieceSafety,
  executeLegalAction,
  getLegalActions,
  selectBestMaterialAction,
  selectBestAlphaBetaAction,
  selectBestIterativeDeepeningAlphaBetaAction,
  selectBestTwoPlyAlphaBetaAction,
  selectBestTwoPlyMinimaxAction,
  TWO_PLY_ALPHA_BETA_SEARCH_DEPTH,
  type LegalAction,
  type MaterialValueTable,
  type PieceSquareValueTable,
  type SearchEvaluationConfig,
} from '../domain/shogi';
import {
  orderAlphaBetaNodeActions,
  orderIterativeDeepeningRootActions,
} from '../domain/shogi/twoPlyAlphaBetaAi';
import {
  createInitialBoardState,
  type BoardState,
  type GameResult,
  type Piece,
  type PieceType,
  type Player,
} from '../types/shogi';

function piece(id: string, type: PieceType, player: Player, isPromoted = false): Piece {
  return { id, type, player, ...(isPromoted ? { isPromoted: true } : {}) };
}

function createState(
  boardPieces: Array<{ row: number; col: number; piece: Piece }>,
  senteHand: Piece[] = [],
  goteHand: Piece[] = [],
  turn: Player = 'sente',
  overrides: Partial<BoardState> = {}
): BoardState {
  const initial = createInitialBoardState();
  const squares = cloneBoardSquares(initial.squares);
  for (const row of squares) for (const square of row) square.piece = null;
  for (const item of boardPieces) squares[item.row][item.col].piece = { ...item.piece };

  return {
    ...initial,
    squares,
    senteHand: senteHand.map((handPiece) => ({ ...handPiece })),
    goteHand: goteHand.map((handPiece) => ({ ...handPiece })),
    turn,
    ...overrides,
  };
}

function opponentOf(player: Player): Player {
  return player === 'sente' ? 'gote' : 'sente';
}

function zeroPieceSquareGrid(): number[][] {
  return Array.from({ length: 9 }, () => Array.from({ length: 9 }, () => 0));
}

const ZERO_PIECE_SQUARE_VALUE_TABLE: PieceSquareValueTable = {
  unpromoted: {
    pawn: zeroPieceSquareGrid(), lance: zeroPieceSquareGrid(), knight: zeroPieceSquareGrid(),
    silver: zeroPieceSquareGrid(), gold: zeroPieceSquareGrid(), bishop: zeroPieceSquareGrid(),
    rook: zeroPieceSquareGrid(), king: zeroPieceSquareGrid(),
  },
  promoted: {
    pawn: zeroPieceSquareGrid(), lance: zeroPieceSquareGrid(), knight: zeroPieceSquareGrid(),
    silver: zeroPieceSquareGrid(), bishop: zeroPieceSquareGrid(), rook: zeroPieceSquareGrid(),
  },
};

function materialOnlyEvaluation(materialValueTable: MaterialValueTable) {
  return { materialValueTable, pieceSquareValueTable: ZERO_PIECE_SQUARE_VALUE_TABLE };
}

/** A tempting silver capture is immediately recaptured by the opposing rook. */
function recaptureTrapState(turn: Player = 'sente'): BoardState {
  const opponent = opponentOf(turn);
  const forwardTarget = turn === 'sente' ? 3 : 5;
  return createState([
    { row: 8, col: 8, piece: piece('sente-king', 'king', 'sente') },
    { row: 0, col: 8, piece: piece('gote-king', 'king', 'gote') },
    { row: 4, col: 4, piece: piece(`${turn}-rook`, 'rook', turn) },
    { row: forwardTarget, col: 4, piece: piece(`${opponent}-pawn`, 'pawn', opponent) },
    { row: 4, col: 5, piece: piece(`${opponent}-silver`, 'silver', opponent) },
    { row: 4, col: 6, piece: piece(`${opponent}-recapturing-rook`, 'rook', opponent) },
  ], [], [], turn);
}

/**
 * The knight pins itself in front of its king, leaving only the pawn move.
 * After that move Gote can checkmate through the existing rook-capture path.
 */
function forcedLossAfterEveryRootActionState(): BoardState {
  return createState([
    { row: 8, col: 4, piece: piece('sente-king', 'king', 'sente') },
    { row: 7, col: 4, piece: piece('sente-knight', 'knight', 'sente') },
    { row: 6, col: 0, piece: piece('sente-pawn', 'pawn', 'sente') },
    { row: 6, col: 4, piece: piece('gote-rook', 'rook', 'gote') },
    { row: 6, col: 3, piece: piece('gote-gold', 'gold', 'gote') },
    { row: 6, col: 5, piece: piece('gote-pawn', 'pawn', 'gote') },
    { row: 6, col: 1, piece: piece('left-escape-guard', 'bishop', 'gote') },
    { row: 6, col: 7, piece: piece('right-escape-guard', 'bishop', 'gote') },
  ]);
}

/** Contains one action from each move-ordering class plus a legal drop. */
function moveOrderingActionState(): BoardState {
  return createState([
    { row: 8, col: 8, piece: piece('sente-king', 'king', 'sente') },
    { row: 0, col: 8, piece: piece('gote-king', 'king', 'gote') },
    { row: 1, col: 4, piece: piece('promotion-capturing-pawn', 'pawn', 'sente') },
    { row: 0, col: 4, piece: piece('captured-silver', 'silver', 'gote') },
    { row: 4, col: 4, piece: piece('capturing-rook', 'rook', 'sente') },
    { row: 4, col: 5, piece: piece('captured-pawn', 'pawn', 'gote') },
    { row: 2, col: 2, piece: piece('promotion-pawn', 'pawn', 'sente') },
  ], [piece('sente-hand-gold', 'gold', 'sente')]);
}

/** A depth-three fixture where an early tactical reply improves cutoffs. */
function moveOrderingBenefitState(): BoardState {
  return createState([
    { row: 8, col: 8, piece: piece('sente-king', 'king', 'sente') },
    { row: 0, col: 8, piece: piece('gote-king', 'king', 'gote') },
    { row: 4, col: 4, piece: piece('sente-rook', 'rook', 'sente') },
    { row: 3, col: 4, piece: piece('gote-pawn-forward', 'pawn', 'gote') },
    { row: 4, col: 5, piece: piece('gote-silver', 'silver', 'gote') },
    { row: 4, col: 6, piece: piece('gote-rook', 'rook', 'gote') },
    { row: 5, col: 4, piece: piece('sente-pawn', 'pawn', 'sente') },
  ]);
}

function execute(state: BoardState, action: LegalAction): BoardState {
  const result = executeLegalAction(cloneBoardState(state), action);
  expect(result.type).toBe('applied');
  if (result.type !== 'applied') throw new Error('Test legal action was rejected.');
  return result.state;
}

/**
 * The first Sente rook move checks Gote. Gote has exactly one legal reply:
 * capturing that rook, which also checks Sente. The supplied position history
 * makes that legal reply the fourth occurrence of a Gote-only checking cycle,
 * so it is adjudicated as a Gote foul loss.
 */
function minimizingPositiveInfinityPrincipalVariationState(): BoardState {
  const state = createState([
    { row: 8, col: 0, piece: piece('sente-king', 'king', 'sente') },
    { row: 2, col: 4, piece: piece('gote-king', 'king', 'gote') },
    { row: 3, col: 0, piece: piece('sente-rook', 'rook', 'sente') },
    { row: 0, col: 0, piece: piece('gote-rook', 'rook', 'gote') },
    { row: 1, col: 3, piece: piece('gote-blocker-1', 'knight', 'gote') },
    { row: 1, col: 4, piece: piece('gote-blocker-2', 'knight', 'gote') },
    { row: 1, col: 5, piece: piece('gote-blocker-3', 'knight', 'gote') },
    { row: 3, col: 3, piece: piece('gote-blocker-4', 'knight', 'gote') },
    { row: 3, col: 4, piece: piece('gote-blocker-5', 'knight', 'gote') },
    { row: 3, col: 5, piece: piece('gote-blocker-6', 'knight', 'gote') },
  ]);
  const checkingMove = findMove(getLegalActions(state), { row: 3, col: 0 }, { row: 2, col: 0 });
  const afterCheckingMove = execute(state, checkingMove);
  const goteReply = findMove(getLegalActions(afterCheckingMove), { row: 0, col: 0 }, { row: 2, col: 0 });
  const terminalPosition = execute(afterCheckingMove, goteReply);
  const terminalKey = createPositionKey(terminalPosition);
  const currentKey = createPositionKey(state);

  return {
    ...state,
    positionHistory: [
      { key: terminalKey, historyIndex: -6, movedBy: 'gote', gaveCheck: true },
      { key: 'non-checking-sente-history', historyIndex: -5, movedBy: 'sente', gaveCheck: false },
      { key: terminalKey, historyIndex: -4, movedBy: 'gote', gaveCheck: true },
      { key: 'other-gote-history', historyIndex: -3, movedBy: 'gote', gaveCheck: true },
      { key: terminalKey, historyIndex: -2, movedBy: 'gote', gaveCheck: true },
      { key: currentKey, historyIndex: 0, movedBy: null, gaveCheck: false },
    ],
  };
}

/**
 * Sente is checked by the Gote bishop and has two legal interpositions. Each
 * interposition checks Gote, whose only reply captures it and checks Sente.
 * The surviving Sente silver then captures that bishop, checks Gote,
 * and reaches the fourth occurrence of its own checking cycle. The first root
 * action reaches the silver capture, which is the depth-three maximizing node.
 */
function maximizingNegativeInfinityPrincipalVariationState(): BoardState {
  const state = createState([
    { row: 8, col: 0, piece: piece('sente-king', 'king', 'sente') },
    { row: 7, col: 0, piece: piece('sente-king-blocker-1', 'pawn', 'sente') },
    { row: 6, col: 3, piece: piece('sente-root-silver', 'silver', 'sente') },
    { row: 6, col: 4, piece: piece('sente-maximizing-silver', 'silver', 'sente') },
    { row: 4, col: 2, piece: piece('gote-king', 'king', 'gote') },
    { row: 4, col: 4, piece: piece('gote-checking-bishop', 'bishop', 'gote') },
    { row: 3, col: 1, piece: piece('gote-blocker-1', 'knight', 'gote') },
    { row: 3, col: 2, piece: piece('gote-blocker-2', 'lance', 'gote') },
    { row: 3, col: 3, piece: piece('gote-blocker-3', 'knight', 'gote') },
    { row: 4, col: 1, piece: piece('gote-blocker-4', 'pawn', 'gote') },
    { row: 5, col: 1, piece: piece('gote-blocker-5', 'pawn', 'gote') },
    { row: 5, col: 2, piece: piece('gote-blocker-6', 'pawn', 'gote') },
    { row: 7, col: 2, piece: piece('gote-king-escape-guard', 'gold', 'gote') },
  ]);
  const firstRootSilver = findMove(getLegalActions(state), { row: 6, col: 3 }, { row: 5, col: 3 });
  const secondRootSilver = findMove(getLegalActions(state), { row: 6, col: 4 }, { row: 5, col: 3 });
  const goteReplyAfterFirstSilver = findMove(
    getLegalActions(execute(state, firstRootSilver)),
    { row: 4, col: 4 },
    { row: 5, col: 3 }
  );
  const goteReplyAfterSecondSilver = findMove(
    getLegalActions(execute(state, secondRootSilver)),
    { row: 4, col: 4 },
    { row: 5, col: 3 }
  );
  const firstSilverLineTerminal = execute(
    execute(execute(state, firstRootSilver), goteReplyAfterFirstSilver),
    findMove(getLegalActions(execute(execute(state, firstRootSilver), goteReplyAfterFirstSilver)), { row: 6, col: 4 }, { row: 5, col: 3 })
  );
  const secondSilverLineTerminal = execute(
    execute(execute(state, secondRootSilver), goteReplyAfterSecondSilver),
    findMove(getLegalActions(execute(execute(state, secondRootSilver), goteReplyAfterSecondSilver)), { row: 6, col: 3 }, { row: 5, col: 3 })
  );
  const currentKey = createPositionKey(state);
  const terminalKeys = [createPositionKey(firstSilverLineTerminal), createPositionKey(secondSilverLineTerminal)];

  return {
    ...state,
    positionHistory: [
      ...terminalKeys.flatMap((key, index) => [
        { key, historyIndex: index * 6 - 12, movedBy: 'sente' as const, gaveCheck: true },
        { key: `non-checking-gote-${index}-1`, historyIndex: index * 6 - 11, movedBy: 'gote' as const, gaveCheck: false },
        { key, historyIndex: index * 6 - 10, movedBy: 'sente' as const, gaveCheck: true },
        { key: `non-checking-gote-${index}-2`, historyIndex: index * 6 - 9, movedBy: 'gote' as const, gaveCheck: false },
        { key, historyIndex: index * 6 - 8, movedBy: 'sente' as const, gaveCheck: true },
      ]),
      { key: currentKey, historyIndex: 0, movedBy: null, gaveCheck: false },
    ],
  };
}

function replayPrincipalVariation(state: BoardState, principalVariation: readonly LegalAction[]): BoardState {
  return principalVariation.reduce((replayState, action) => {
    expect(getLegalActions(replayState).some((legalAction) => areLegalActionsEqual(legalAction, action)))
      .toBe(true);
    return execute(replayState, action);
  }, cloneBoardState(state));
}

function expectEvaluationBreakdownToMatchPrincipalVariation(
  state: BoardState,
  result: {
    selectedEvaluation: number | null;
    principalVariation: readonly LegalAction[];
    evaluationBreakdown: ReturnType<typeof evaluateSearchPositionBreakdown> | null;
  },
  evaluation?: SearchEvaluationConfig
): void {
  const leaf = replayPrincipalVariation(state, result.principalVariation);
  const expected = evaluateSearchPositionBreakdown(leaf, state.turn, evaluation);

  expect(result.evaluationBreakdown).toEqual(expected);
  if (result.selectedEvaluation !== null) {
    expect(result.selectedEvaluation).toBe(result.evaluationBreakdown?.total);
  }
}

/**
 * A deliberately small, test-only minimax reference. It uses the public
 * search primitives but does not carry alpha or beta, so it explores every
 * legal branch up to the supplied ply depth. Production code must continue to
 * use the single alpha-beta implementation instead of this helper.
 */
function analyzeUnprunedMinimaxForTest(
  state: BoardState,
  depth: number,
  valueTable?: MaterialValueTable
): {
  selectedAction: LegalAction | null;
  selectedEvaluation: number | null;
  visitedPositionCount: number;
  deepestEvaluatedPly: number;
  terminalLeafCount: number;
} {
  const rootPlayer = state.turn;
  let visitedPositionCount = 0;
  let deepestEvaluatedPly = 0;
  let terminalLeafCount = 0;

  const evaluateLeaf = (position: BoardState, ply: number): number => {
    deepestEvaluatedPly = Math.max(deepestEvaluatedPly, ply);
    if (position.status === 'ended') terminalLeafCount += 1;
    return evaluateSearchPosition(position, rootPlayer, valueTable);
  };

  const searchNode = (position: BoardState, remainingDepth: number, maximizing: boolean, ply: number): number => {
    if (position.status === 'ended' || remainingDepth === 0) {
      return evaluateLeaf(position, ply);
    }

    const actions = getLegalActions(position);
    if (actions.length === 0) return evaluateLeaf(position, ply);

    let value = maximizing ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY;
    for (const action of actions) {
      const child = execute(position, action);
      visitedPositionCount += 1;
      const childValue = searchNode(child, remainingDepth - 1, !maximizing, ply + 1);
      if (maximizing ? childValue > value : childValue < value) value = childValue;
    }
    return value;
  };

  if (depth === 0) {
    return {
      selectedAction: null,
      selectedEvaluation: evaluateLeaf(state, 0),
      visitedPositionCount,
      deepestEvaluatedPly,
      terminalLeafCount,
    };
  }

  let selectedAction: LegalAction | null = null;
  let selectedEvaluation = Number.NEGATIVE_INFINITY;
  for (const action of getLegalActions(state)) {
    const child = execute(state, action);
    visitedPositionCount += 1;
    const candidateEvaluation = searchNode(child, depth - 1, false, 1);
    if (selectedAction === null || candidateEvaluation > selectedEvaluation) {
      selectedAction = action;
      selectedEvaluation = candidateEvaluation;
    }
  }

  return {
    selectedAction,
    selectedEvaluation: selectedAction === null ? null : selectedEvaluation,
    visitedPositionCount,
    deepestEvaluatedPly,
    terminalLeafCount,
  };
}

/**
 * Test-only alpha-beta baseline that intentionally keeps every non-root
 * `getLegalActions` order. It makes the move-ordering node reduction
 * measurable without adding another production search implementation.
 */
function analyzeUnorderedAlphaBetaForTest(
  state: BoardState,
  depth: number,
  valueTable?: MaterialValueTable
): {
  selectedAction: LegalAction | null;
  selectedEvaluation: number | null;
  visitedPositionCount: number;
  cutoffCount: number;
  skippedActionCount: number;
} {
  const rootPlayer = state.turn;
  let visitedPositionCount = 0;
  let cutoffCount = 0;
  let skippedActionCount = 0;

  const searchNode = (
    position: BoardState,
    remainingDepth: number,
    maximizing: boolean,
    alpha: number,
    beta: number
  ): number => {
    if (position.status === 'ended' || remainingDepth === 0) {
      return evaluateSearchPosition(position, rootPlayer, valueTable);
    }

    const actions = getLegalActions(position);
    if (actions.length === 0) return evaluateSearchPosition(position, rootPlayer, valueTable);

    let value = maximizing ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY;
    for (let actionIndex = 0; actionIndex < actions.length; actionIndex += 1) {
      const child = execute(position, actions[actionIndex]);
      visitedPositionCount += 1;
      const childValue = searchNode(child, remainingDepth - 1, !maximizing, alpha, beta);
      if (maximizing) {
        if (childValue > value) value = childValue;
        if (value > alpha) alpha = value;
      } else {
        if (childValue < value) value = childValue;
        if (value < beta) beta = value;
      }

      const remainingActionCount = actions.length - actionIndex - 1;
      if (alpha >= beta && remainingActionCount > 0) {
        cutoffCount += 1;
        skippedActionCount += remainingActionCount;
        break;
      }
    }
    return value;
  };

  if (depth === 0) {
    return {
      selectedAction: null,
      selectedEvaluation: evaluateSearchPosition(state, rootPlayer, valueTable),
      visitedPositionCount,
      cutoffCount,
      skippedActionCount,
    };
  }

  let selectedAction: LegalAction | null = null;
  let selectedEvaluation = Number.NEGATIVE_INFINITY;
  let alpha = Number.NEGATIVE_INFINITY;
  const beta = Number.POSITIVE_INFINITY;
  for (const action of getLegalActions(state)) {
    const child = execute(state, action);
    visitedPositionCount += 1;
    const candidateEvaluation = searchNode(child, depth - 1, false, alpha, beta);
    if (selectedAction === null || candidateEvaluation > selectedEvaluation) {
      selectedAction = action;
      selectedEvaluation = candidateEvaluation;
    }
    if (selectedEvaluation > alpha) alpha = selectedEvaluation;
  }

  return {
    selectedAction,
    selectedEvaluation: selectedAction === null ? null : selectedEvaluation,
    visitedPositionCount,
    cutoffCount,
    skippedActionCount,
  };
}

function findMove(
  actions: LegalAction[],
  from: { row: number; col: number },
  to: { row: number; col: number }
): LegalAction {
  const action = actions.find(
    (candidate) => candidate.kind === 'move' &&
      candidate.from.row === from.row && candidate.from.col === from.col &&
      candidate.to.row === to.row && candidate.to.col === to.col
  );
  if (!action) throw new Error('Expected move was not legal in the test position.');
  return action;
}

describe('再帰型αβ探索の手の並べ替え', () => {
  it('SEEが高い成り付き捕獲、通常捕獲、非捕獲成り、その他の順と同点の元順を保つ', () => {
    const state = moveOrderingActionState();
    const actions = getLegalActions(state);
    const capturePromotion = actions.find((action) => action.kind === 'move' &&
      action.from.row === 1 && action.from.col === 4 && action.to.row === 0 && action.to.col === 4 &&
      action.promotion === 'promote');
    const capture = actions.find((action) => action.kind === 'move' &&
      action.from.row === 4 && action.from.col === 4 && action.to.row === 4 && action.to.col === 5);
    const promotion = actions.find((action) => action.kind === 'move' &&
      action.from.row === 2 && action.from.col === 2 && action.to.row === 1 && action.to.col === 2 &&
      action.promotion === 'promote');
    const normal = actions.find((action) => action.kind === 'move' &&
      action.from.row === 4 && action.from.col === 4 && action.to.row === 4 && action.to.col === 3);
    const anotherNormal = actions.find((action) => action.kind === 'move' &&
      action.from.row === 4 && action.from.col === 4 && action.to.row === 3 && action.to.col === 4 &&
      action.promotion === 'none');
    const drop = actions.find((action) => action.kind === 'drop');
    if (!capturePromotion || !capture || !promotion || !normal || !anotherNormal || !drop) {
      throw new Error('Expected every move-ordering class in the fixture.');
    }

    const source = [normal, drop, anotherNormal, promotion, capture, capturePromotion];

    expect(orderAlphaBetaNodeActions(state, source, undefined, undefined, { moveOrdering: 'static-exchange' })).toEqual([
      capturePromotion,
      capture,
      promotion,
      normal,
      drop,
      anotherNormal,
    ]);
  });

  it('駒打ちをその他として扱い、元の候補配列と入力局面を変更しない', () => {
    const state = moveOrderingActionState();
    const snapshot = JSON.stringify(state);
    const source = getLegalActions(state);
    const sourceSnapshot = [...source];
    const ordered = orderAlphaBetaNodeActions(state, source);
    const firstDropIndex = ordered.findIndex((action) => action.kind === 'drop');
    const firstPriorityThreeIndex = ordered.findIndex((action) => action.kind === 'move' &&
      action.promotion !== 'promote' && state.squares[action.to.row][action.to.col].piece === null);

    expect(ordered).not.toBe(source);
    expect(source).toEqual(sourceSnapshot);
    expect(firstDropIndex).toBeGreaterThanOrEqual(firstPriorityThreeIndex);
    expect(JSON.stringify(state)).toBe(snapshot);
  });

  it('root候補は並べ替えず、同点では元の先頭手を選ぶ', () => {
    const state = createState([
      { row: 8, col: 8, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 8, piece: piece('gote-king', 'king', 'gote') },
      { row: 4, col: 4, piece: piece('sente-rook', 'rook', 'sente') },
      { row: 4, col: 5, piece: piece('gote-pawn', 'pawn', 'gote') },
    ]);
    const rootActions = getLegalActions(state);
    const zeroValueTable: MaterialValueTable = {
      unpromoted: { pawn: 0, lance: 0, knight: 0, silver: 0, gold: 0, bishop: 0, rook: 0, king: 0 },
      promoted: { pawn: 0, lance: 0, knight: 0, silver: 0, bishop: 0, rook: 0 },
    };

    expect(orderAlphaBetaNodeActions(state, rootActions)[0]).not.toEqual(rootActions[0]);
    expect(analyzeAlphaBetaSearch(state, 1, materialOnlyEvaluation(zeroValueTable)).selectedAction).toEqual(rootActions[0]);
  });

  it('深さ3では並べ替えなしαβより少ない局面を生成し、選択手と評価値を保つ', () => {
    const state = moveOrderingBenefitState();
    const unordered = analyzeUnorderedAlphaBetaForTest(state, 3);
    const ordered = analyzeAlphaBetaSearch(state, 3);
    const minimax = analyzeUnprunedMinimaxForTest(state, 3);

    expect(ordered.selectedAction).toEqual(unordered.selectedAction);
    expect(ordered.selectedEvaluation).toBe(unordered.selectedEvaluation);
    expect(ordered.selectedAction).toEqual(minimax.selectedAction);
    expect(ordered.selectedEvaluation).toBe(minimax.selectedEvaluation);
    expect(ordered.visitedPositionCount).toBeLessThan(unordered.visitedPositionCount);
    // Recorded on pre-SEE main a964fd6; ordering must not change the root answer.
    expect(ordered.selectedAction).toMatchObject({ from: { row: 4, col: 4 }, to: { row: 4, col: 2 } });
    expect(ordered.selectedEvaluation).toBe(-575);
    expect(ordered.principalVariation).toMatchObject([
      { from: { row: 4, col: 4 }, to: { row: 4, col: 2 }, promotion: 'none' },
      { from: { row: 4, col: 6 }, to: { row: 8, col: 6 }, promotion: 'promote' },
      { from: { row: 8, col: 8 }, to: { row: 7, col: 8 }, promotion: 'none' },
    ]);
  });
});

describe('反復深化αβ探索', () => {
  it.each(['standard', 'static-exchange'] as const)('初期局面の固定深さ3は選択手、評価値、PVと%sの統計を保つ', (moveOrdering) => {
    const state = createInitialBoardState();
    const snapshot = JSON.stringify(state);
    const result = analyzeAlphaBetaSearch(state, 3, undefined, undefined, { moveOrdering });

    expect(result).toMatchObject({
      selectedAction: {
        kind: 'move', from: { row: 6, col: 2 }, to: { row: 5, col: 2 },
        pieceType: 'pawn', promotion: 'none',
      },
      selectedEvaluation: 214,
      // Recorded statistics from pre-SEE main and the parent SEE implementation.
      // Both modes retain 80 cutoffs and the same root answer.
      visitedPositionCount: moveOrdering === 'standard' ? 1244 : 1267,
      cutoffCount: 80,
      skippedActionCount: moveOrdering === 'standard' ? 2565 : 2542,
    });
    expect(result.principalVariation).toMatchObject([
      { kind: 'move', from: { row: 6, col: 2 }, to: { row: 5, col: 2 } },
      { kind: 'move', from: { row: 2, col: 5 }, to: { row: 3, col: 5 } },
      { kind: 'move', from: { row: 7, col: 1 }, to: { row: 3, col: 5 } },
    ]);
    expect(JSON.stringify(state)).toBe(snapshot);
  });

  it('最大深さ3では深さ1、2、3を順に完了し、最深反復を最終結果として返す', () => {
    const state = moveOrderingBenefitState();
    const directDepth3 = analyzeAlphaBetaSearch(state, 3, undefined, () => 0);
    const iterative = analyzeIterativeDeepeningAlphaBetaSearch(state, 3, undefined, () => 0);

    expect(iterative.iterations.map((iteration) => iteration.depth)).toEqual([1, 2, 3]);
    expect(iterative.selectedAction).toEqual(directDepth3.selectedAction);
    expect(iterative.selectedEvaluation).toBe(directDepth3.selectedEvaluation);
    expect(iterative.visitedPositionCount).toBe(iterative.iterations[2].visitedPositionCount);
    expect(iterative.cutoffCount).toBe(iterative.iterations[2].cutoffCount);
    expect(iterative.skippedActionCount).toBe(iterative.iterations[2].skippedActionCount);
  });

  it('最大深さ1では深さ1だけを実行し、その結果を返す', () => {
    const state = recaptureTrapState();
    const directDepth1 = analyzeAlphaBetaSearch(state, 1, undefined, () => 0);
    const iterative = analyzeIterativeDeepeningAlphaBetaSearch(state, 1, undefined, () => 0);

    expect(iterative.iterations).toHaveLength(1);
    expect(iterative.iterations[0]).toMatchObject(directDepth1);
    expect(iterative.selectedAction).toEqual(directDepth1.selectedAction);
    expect(selectBestIterativeDeepeningAlphaBetaAction(state, 1)).toEqual(directDepth1.selectedAction);
  });

  it('前回最善手をroot先頭へ置き、残りは既存の分類順にする', () => {
    const state = moveOrderingActionState();
    const rootActions = getLegalActions(state);
    const previousBestAction = rootActions.find((action) => action.kind === 'move' &&
      action.from.row === 4 && action.from.col === 4 && action.to.row === 4 && action.to.col === 5);
    if (!previousBestAction) throw new Error('Expected a non-leading previous best action.');

    const ordered = orderIterativeDeepeningRootActions(state, rootActions, previousBestAction);
    const expectedRemaining = orderAlphaBetaNodeActions(
      state,
      rootActions.filter((action) => action !== previousBestAction)
    );

    expect(ordered[0]).toEqual(previousBestAction);
    expect(ordered.slice(1)).toEqual(expectedRemaining);
    expect(rootActions).not.toEqual(ordered);
  });

  it('前回最善手が現局面の合法手にない場合は既存root順で続行する', () => {
    const state = moveOrderingActionState();
    const rootActions = getLegalActions(state);
    const unavailableAction = getLegalActions(execute(state, rootActions[0]))[0];

    expect(orderIterativeDeepeningRootActions(state, rootActions, unavailableAction)).toEqual(rootActions);
    expect(analyzeIterativeDeepeningAlphaBetaSearch(state, 2).selectedAction).toEqual(
      analyzeAlphaBetaSearch(state, 2).selectedAction
    );
  });

  it('探索順が変わっても同点時は元の合法手順の先頭を選ぶ', () => {
    const state = createState([
      { row: 8, col: 8, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 8, piece: piece('gote-king', 'king', 'gote') },
      { row: 4, col: 4, piece: piece('sente-rook', 'rook', 'sente') },
      { row: 4, col: 5, piece: piece('gote-pawn', 'pawn', 'gote') },
    ]);
    const rootActions = getLegalActions(state);
    const zeroValueTable: MaterialValueTable = {
      unpromoted: { pawn: 0, lance: 0, knight: 0, silver: 0, gold: 0, bishop: 0, rook: 0, king: 0 },
      promoted: { pawn: 0, lance: 0, knight: 0, silver: 0, bishop: 0, rook: 0 },
    };

    const forcedReorder = orderIterativeDeepeningRootActions(state, rootActions, rootActions.at(-1) ?? null);
    expect(forcedReorder[0]).not.toEqual(rootActions[0]);
    expect(analyzeIterativeDeepeningAlphaBetaSearch(state, 2, materialOnlyEvaluation(zeroValueTable)).selectedAction).toEqual(rootActions[0]);
  });

  it('深さ別統計を独立して記録し、累計を二重加算しない', () => {
    const state = moveOrderingBenefitState();
    const iterative = analyzeIterativeDeepeningAlphaBetaSearch(state, 3, undefined, () => 0);
    const totals = iterative.iterations.reduce(
      (sum, iteration) => ({
        visited: sum.visited + iteration.visitedPositionCount,
        cutoffs: sum.cutoffs + iteration.cutoffCount,
        skipped: sum.skipped + iteration.skippedActionCount,
      }),
      { visited: 0, cutoffs: 0, skipped: 0 }
    );

    expect(iterative.iterations.every((iteration) => iteration.rootLegalActionCount > 0)).toBe(true);
    expect(iterative.totalVisitedPositionCount).toBe(totals.visited);
    expect(iterative.totalCutoffCount).toBe(totals.cutoffs);
    expect(iterative.totalSkippedActionCount).toBe(totals.skipped);
    expect(iterative.totalVisitedPositionCount).toBeGreaterThan(iterative.visitedPositionCount);
  });

  it('専用局面の深さ3でも選択手4,4 -> 4,0と危険度評価込みの-570を保ち、結果と統計は決定的', () => {
    const state = moveOrderingBenefitState();
    const snapshot = JSON.stringify(state);
    const evaluation = materialOnlyEvaluation({
      unpromoted: { pawn: 100, lance: 300, knight: 300, silver: 400, gold: 500, bishop: 800, rook: 1000, king: 0 },
      promoted: { pawn: 500, lance: 500, knight: 500, silver: 500, bishop: 1000, rook: 1200 },
    });
    const first = analyzeIterativeDeepeningAlphaBetaSearch(state, 3, evaluation, () => 0);
    const second = analyzeIterativeDeepeningAlphaBetaSearch(state, 3, evaluation, () => 0);

    expect(first.selectedAction).toMatchObject({
      kind: 'move', from: { row: 4, col: 4 }, to: { row: 4, col: 0 },
    });
    // The selected leaf is still the same action; the prior 30-point
    // undefended-piece warning is joined by a 3-point King-safety penalty.
    expect(first.selectedEvaluation).toBe(-573);
    expect(second).toMatchObject({
      selectedAction: first.selectedAction,
      selectedEvaluation: first.selectedEvaluation,
      visitedPositionCount: first.visitedPositionCount,
      cutoffCount: first.cutoffCount,
      skippedActionCount: first.skippedActionCount,
      totalVisitedPositionCount: first.totalVisitedPositionCount,
      totalCutoffCount: first.totalCutoffCount,
      totalSkippedActionCount: first.totalSkippedActionCount,
    });
    expect(JSON.stringify(state)).toBe(snapshot);
  });

  it('終局局面でも各反復を安全に完了し、無効な最大深さを拒否する', () => {
    const ended = {
      ...recaptureTrapState(),
      status: 'ended' as const,
      result: { winner: null, loser: null, endReason: 'repetition' } satisfies GameResult,
    };
    const result = analyzeIterativeDeepeningAlphaBetaSearch(ended, 3, undefined, () => 0);

    expect(result.iterations).toHaveLength(3);
    expect(result.iterations.every((iteration) => iteration.selectedAction === null)).toBe(true);
    expect(result.totalVisitedPositionCount).toBe(0);
    expect(result.totalCutoffCount).toBe(0);
    expect(result.totalSkippedActionCount).toBe(0);
    expect(() => analyzeIterativeDeepeningAlphaBetaSearch(ended, 0)).toThrow(/positive integer/);
    expect(() => analyzeIterativeDeepeningAlphaBetaSearch(ended, -1)).toThrow(/non-negative integer/);
    expect(() => analyzeIterativeDeepeningAlphaBetaSearch(ended, 1.5)).toThrow(/non-negative integer/);
  });
});

describe('時間制限付き反復深化αβ探索', () => {
  function countClockReadsThroughDepthTwo(state: BoardState): number {
    let readCount = 0;
    analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(
      state,
      2,
      Number.MAX_SAFE_INTEGER,
      undefined,
      () => {
        readCount += 1;
        return 0;
      }
    );
    return readCount;
  }

  it('十分な制限時間では最大深さまで完了し、時間制限なしの結果を保つ', () => {
    const state = moveOrderingBenefitState();
    const snapshot = JSON.stringify(state);
    const evaluation = materialOnlyEvaluation({
      unpromoted: { pawn: 100, lance: 300, knight: 300, silver: 400, gold: 500, bishop: 800, rook: 1000, king: 0 },
      promoted: { pawn: 500, lance: 500, knight: 500, silver: 500, bishop: 1000, rook: 1200 },
    });
    const unlimited = analyzeIterativeDeepeningAlphaBetaSearch(state, 3, evaluation, () => 0);
    const limited = analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(
      state,
      3,
      Number.MAX_SAFE_INTEGER,
      evaluation,
      () => 0
    );

    expect(limited).toMatchObject({ requestedMaxDepth: 3, completedDepth: 3, timedOut: false });
    expect(limited.iterations.map((iteration) => iteration.depth)).toEqual([1, 2, 3]);
    expect(limited.selectedAction).toEqual(unlimited.selectedAction);
    expect(limited.selectedEvaluation).toBe(unlimited.selectedEvaluation);
    expect(limited.visitedPositionCount).toBe(unlimited.visitedPositionCount);
    expect(limited.cutoffCount).toBe(unlimited.cutoffCount);
    expect(limited.skippedActionCount).toBe(unlimited.skippedActionCount);
    expect(limited.selectedAction).toMatchObject({
      kind: 'move', from: { row: 4, col: 4 }, to: { row: 4, col: 0 },
    });
    expect(limited.selectedEvaluation).toBe(-573);
    expect(JSON.stringify(state)).toBe(snapshot);
  });

  it('深さ3の再帰中に期限へ達すると、深さ2だけを採用して途中統計を混ぜない', () => {
    const state = moveOrderingBenefitState();
    const completedDepthTwoReadCount = countClockReadsThroughDepthTwo(state);
    let readCount = 0;
    const clock = () => {
      readCount += 1;
      return readCount >= completedDepthTwoReadCount + 5 ? 10 : 0;
    };
    const result = analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(state, 3, 10, undefined, clock);
    const depthTwo = analyzeIterativeDeepeningAlphaBetaSearch(state, 2, undefined, () => 0);
    const totals = result.iterations.reduce(
      (sum, iteration) => ({
        visited: sum.visited + iteration.visitedPositionCount,
        cutoffs: sum.cutoffs + iteration.cutoffCount,
        skipped: sum.skipped + iteration.skippedActionCount,
      }),
      { visited: 0, cutoffs: 0, skipped: 0 }
    );

    expect(result).toMatchObject({ requestedMaxDepth: 3, completedDepth: 2, timedOut: true });
    expect(result.iterations.map((iteration) => iteration.depth)).toEqual([1, 2]);
    expect(result.selectedAction).toEqual(depthTwo.selectedAction);
    expect(result.selectedEvaluation).toBe(depthTwo.selectedEvaluation);
    expect(result.evaluationBreakdown).toEqual(depthTwo.evaluationBreakdown);
    expectEvaluationBreakdownToMatchPrincipalVariation(state, result);
    expect(result.visitedPositionCount).toBe(result.iterations[1].visitedPositionCount);
    expect(result.cutoffCount).toBe(result.iterations[1].cutoffCount);
    expect(result.skippedActionCount).toBe(result.iterations[1].skippedActionCount);
    expect(result.totalVisitedPositionCount).toBe(totals.visited);
    expect(result.totalCutoffCount).toBe(totals.cutoffs);
    expect(result.totalSkippedActionCount).toBe(totals.skipped);
    expect(result.elapsedMilliseconds).toBe(10);
  });

  it('深さ2の探索本体後に期限と同値なら、その完了結果も破棄する', () => {
    const state = recaptureTrapState();
    const completedDepthTwoReadCount = countClockReadsThroughDepthTwo(state);
    const depthOne = analyzeIterativeDeepeningAlphaBetaSearch(state, 1, undefined, () => 0);
    let readCount = 0;
    const result = analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(
      state,
      2,
      10,
      undefined,
      () => {
        readCount += 1;
        return readCount >= completedDepthTwoReadCount - 1 ? 10 : 0;
      }
    );

    expect(readCount).toBe(completedDepthTwoReadCount);
    expect(result).toMatchObject({ requestedMaxDepth: 2, completedDepth: 1, timedOut: true });
    expect(result.iterations.map((iteration) => iteration.depth)).toEqual([1]);
    expect(result.selectedAction).toEqual(depthOne.selectedAction);
    expect(result.selectedEvaluation).toBe(depthOne.selectedEvaluation);
    expect(result.evaluationBreakdown).toEqual(depthOne.evaluationBreakdown);
    expectEvaluationBreakdownToMatchPrincipalVariation(state, result);
    expect(result.visitedPositionCount).toBe(depthOne.visitedPositionCount);
    expect(result.cutoffCount).toBe(depthOne.cutoffCount);
    expect(result.skippedActionCount).toBe(depthOne.skippedActionCount);
    expect(result.totalVisitedPositionCount).toBe(depthOne.totalVisitedPositionCount);
    expect(result.totalCutoffCount).toBe(depthOne.totalCutoffCount);
    expect(result.totalSkippedActionCount).toBe(depthOne.totalSkippedActionCount);
    expect(result.elapsedMilliseconds).toBe(10);
  });

  it('完了反復ごとの時間と、未完了反復を含む全体時間を分離する', () => {
    const state = moveOrderingBenefitState();
    const completedDepthTwoReadCount = countClockReadsThroughDepthTwo(state);
    let readCount = 0;
    const clock = () => {
      readCount += 1;
      if (readCount === 1) return 100;
      if (readCount === 2) return 102;
      if (readCount === 3) return 105;
      if (readCount === 4) return 106;
      if (readCount === 5) return 110;
      if (readCount < completedDepthTwoReadCount - 1) return 110;
      if (readCount === completedDepthTwoReadCount - 1) return 120;
      if (readCount === completedDepthTwoReadCount) return 130;
      return 137;
    };
    const result = analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(state, 3, 30, undefined, clock);

    expect(result).toMatchObject({ completedDepth: 2, timedOut: true, elapsedMilliseconds: 37 });
    expect(result.iterations.map((iteration) => iteration.elapsedMilliseconds)).toEqual([5, 10]);
    expect(result.elapsedMilliseconds).not.toBe(result.iterations[1].elapsedMilliseconds);
  });

  it('0ミリ秒では探索せず、先頭合法手を未評価のfallbackとして返す', () => {
    const state = recaptureTrapState();
    const result = analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(state, 2, 0, undefined, () => 0);

    expect(result).toMatchObject({ completedDepth: 0, depth: 0, timedOut: true, resultSource: 'fallback',
      selectedAction: getLegalActions(state)[0], selectedEvaluation: null, evaluationBreakdown: null,
      principalVariation: [], rootLegalActionCount: getLegalActions(state).length });
    expect(result.iterations).toEqual([]);
    expect(result.visitedPositionCount).toBe(0);
    expect(result.totalVisitedPositionCount).toBe(0);
  });

  it('root合法手の準備時間も期限に含め、深さ1の途中結果を採用しない', () => {
    const state = recaptureTrapState();
    let reads = 0;
    const expiredDuringSetup = analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(
      state, 2, 10, undefined, () => ++reads === 1 ? 0 : 10
    );
    expect(expiredDuringSetup).toMatchObject({ completedDepth: 0, elapsedMilliseconds: 10,
      resultSource: 'fallback', selectedAction: getLegalActions(state)[0] });

    reads = 0;
    const interrupted = analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(
      state, 2, 10, undefined, () => ++reads >= 5 ? 10 : 0
    );
    expect(reads).toBeGreaterThanOrEqual(5);
    expect(interrupted).toMatchObject({ completedDepth: 0, timedOut: true, resultSource: 'fallback',
      selectedAction: getLegalActions(state)[0], selectedEvaluation: null, evaluationBreakdown: null,
      principalVariation: [], visitedPositionCount: 0, totalVisitedPositionCount: 0 });
    expect(interrupted.iterations).toEqual([]);
  });

  it('深さ1の静止探索中に期限へ達しても完了統計へ混ぜない', () => {
    const state = recaptureTrapState();
    let reads = 0;
    const result = analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(
      state, 2, 10, undefined, () => ++reads >= 6 ? 10 : 0,
      { quiescence: { maxTacticalDepth: 1 } }
    );
    expect(reads).toBeGreaterThanOrEqual(6);
    expect(result).toMatchObject({ completedDepth: 0, timedOut: true, resultSource: 'fallback',
      selectedAction: getLegalActions(state)[0], quiescenceLeafCount: 0,
      quiescenceVisitedPositionCount: 0, totalQuiescenceLeafCount: 0,
      totalQuiescenceVisitedPositionCount: 0 });
    expect(result.iterations).toEqual([]);
  });

  it('終局の0ミリ秒は元の終局結果を返し、凍結入力を変えない', () => {
    const state = recaptureTrapState();
    const ended = { ...state, status: 'ended' as const,
      result: { winner: null, loser: null, endReason: 'repetition' as const } };
    const freeze = (value: unknown): void => {
      if (value && typeof value === 'object' && !Object.isFrozen(value)) {
        Object.values(value).forEach(freeze);
        Object.freeze(value);
      }
    };
    freeze(state);
    freeze(ended);
    const snapshot = JSON.stringify(state);
    const first = analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(state, 2, 0, undefined, () => 0);
    const second = analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(state, 2, 0, undefined, () => 0);
    expect(first.selectedAction).toEqual(getLegalActions(state)[0]);
    expect(second.selectedAction).toEqual(first.selectedAction);
    expect(JSON.stringify(state)).toBe(snapshot);
    expect(analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(ended, 2, 0, undefined, () => 0))
      .toMatchObject({ selectedAction: null, completedDepth: 0, resultSource: 'ended-position', terminalResult:ended.result, timedOut: false });
  });

  it('最大深さ1も期限切れならfallbackを返す', () => {
    const state = recaptureTrapState();
    const readings = [0, 1, 2, 3];
    const result = analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(
      state,
      1,
      0,
      undefined,
      () => readings.shift() ?? 3
    );

    expect(result).toMatchObject({ requestedMaxDepth: 1, completedDepth: 0, timedOut: true, resultSource: 'fallback' });
    expect(result.iterations).toHaveLength(0);
  });

  it('有限でない値と負数の時間制限を拒否し、時間切れ以外の例外を伝播する', () => {
    const state = recaptureTrapState();

    expect(() => analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(state, 2, Number.NaN)).toThrow(/finite non-negative/);
    expect(() => analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(state, 2, Number.POSITIVE_INFINITY)).toThrow(/finite non-negative/);
    expect(() => analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(state, 2, -1)).toThrow(/finite non-negative/);

    let readCount = 0;
    expect(() => analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(
      state,
      2,
      Number.MAX_SAFE_INTEGER,
      undefined,
      () => {
        readCount += 1;
        if (readCount === 6) throw new Error('clock failure');
        return 0;
      }
    )).toThrow('clock failure');
  });

  it('同じ局面とclock系列では、時間制限付きの結果と統計も決定的に保つ', () => {
    const state = moveOrderingBenefitState();
    const snapshot = JSON.stringify(state);
    const first = analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(
      state, 3, Number.MAX_SAFE_INTEGER, undefined, () => 0
    );
    const second = analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(
      state, 3, Number.MAX_SAFE_INTEGER, undefined, () => 0
    );

    expect(second).toMatchObject({
      selectedAction: first.selectedAction,
      selectedEvaluation: first.selectedEvaluation,
      completedDepth: first.completedDepth,
      timedOut: first.timedOut,
      visitedPositionCount: first.visitedPositionCount,
      cutoffCount: first.cutoffCount,
      skippedActionCount: first.skippedActionCount,
      totalVisitedPositionCount: first.totalVisitedPositionCount,
      totalCutoffCount: first.totalCutoffCount,
      totalSkippedActionCount: first.totalSkippedActionCount,
    });
    expect(JSON.stringify(state)).toBe(snapshot);
  });
});

describe('探索用局面評価', () => {
  it('active/checkでは駒得、駒位置、玉安全度、守られていない駒の危険度を合成する', () => {
    const state = createState([
      { row: 8, col: 8, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 8, piece: piece('gote-king', 'king', 'gote') },
      { row: 4, col: 4, piece: piece('sente-rook', 'rook', 'sente') },
      { row: 4, col: 5, piece: piece('gote-silver', 'silver', 'gote') },
    ]);
    const table: MaterialValueTable = {
      unpromoted: { pawn: 1, lance: 2, knight: 3, silver: 5, gold: 6, bishop: 7, rook: 11, king: 0 },
      promoted: { pawn: 12, lance: 13, knight: 14, silver: 15, bishop: 16, rook: 17 },
    };

    const evaluation = materialOnlyEvaluation(table);
    expect(evaluateSearchPosition(state, 'sente', evaluation)).toBe(
      evaluateMaterial(state, 'sente', table) +
      evaluatePieceSquarePosition(state, 'sente', ZERO_PIECE_SQUARE_VALUE_TABLE) +
      evaluateKingSafety(state, 'sente', DEFAULT_KING_SAFETY_EVALUATION_WEIGHTS) +
      evaluateUndefendedPieceSafety(state, 'sente', table)
    );
    expect(evaluateSearchPosition({ ...state, status: 'check' }, 'gote', evaluation)).toBe(
      evaluateMaterial(state, 'gote', table) +
      evaluatePieceSquarePosition(state, 'gote', ZERO_PIECE_SQUARE_VALUE_TABLE) +
      evaluateKingSafety(state, 'gote', DEFAULT_KING_SAFETY_EVALUATION_WEIGHTS) +
      evaluateUndefendedPieceSafety(state, 'gote', table)
    );
  });

  it('玉周辺の利き、視点、カスタム重み、重み0を共通探索評価へ反映し、入力を変更しない', () => {
    const safe = createState([
      { row: 8, col: 4, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 4, piece: piece('gote-king', 'king', 'gote') },
      { row: 5, col: 3, piece: piece('gote-pawn', 'pawn', 'gote') },
    ]);
    const exposed = createState([
      { row: 8, col: 4, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 4, piece: piece('gote-king', 'king', 'gote') },
      { row: 7, col: 3, piece: piece('gote-pawn', 'pawn', 'gote') },
    ]);
    const zeroMaterialValueTable: MaterialValueTable = {
      unpromoted: { pawn: 0, lance: 0, knight: 0, silver: 0, gold: 0, bishop: 0, rook: 0, king: 0 },
      promoted: { pawn: 0, lance: 0, knight: 0, silver: 0, bishop: 0, rook: 0 },
    };
    const kingSafetyWeights = { kingSquareAttack: 40, uncoveredAdjacentAttack: 3 };
    const evaluation = {
      materialValueTable: zeroMaterialValueTable,
      pieceSquareValueTable: ZERO_PIECE_SQUARE_VALUE_TABLE,
      kingSafetyWeights,
    };
    const zeroKingSafety = {
      materialValueTable: zeroMaterialValueTable,
      pieceSquareValueTable: ZERO_PIECE_SQUARE_VALUE_TABLE,
      kingSafetyWeights: { kingSquareAttack: 0, uncoveredAdjacentAttack: 0 },
    };
    const safeSnapshot = JSON.stringify(safe);
    const exposedSnapshot = JSON.stringify(exposed);
    const evaluationSnapshot = JSON.stringify(evaluation);

    const safetyDifference = evaluateKingSafety(exposed, 'sente', kingSafetyWeights) -
      evaluateKingSafety(safe, 'sente', kingSafetyWeights);
    expect(safetyDifference).toBeLessThan(0);
    expect(evaluateSearchPosition(exposed, 'sente', evaluation) -
      evaluateSearchPosition(safe, 'sente', evaluation)).toBe(safetyDifference);
    expect(evaluateSearchPosition(exposed, 'gote', evaluation)).toBe(
      -evaluateSearchPosition(exposed, 'sente', evaluation)
    );
    expect(evaluateSearchPosition(exposed, 'sente', zeroKingSafety)).toBe(0);
    expect(JSON.stringify(safe)).toBe(safeSnapshot);
    expect(JSON.stringify(exposed)).toBe(exposedSnapshot);
    expect(JSON.stringify(evaluation)).toBe(evaluationSnapshot);
  });

  it('旧MaterialValueTable形式でも既定の玉安全度を使い、探索経路は共通評価を利用する', () => {
    const state = createState([
      { row: 8, col: 4, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 4, piece: piece('gote-king', 'king', 'gote') },
      { row: 7, col: 3, piece: piece('gote-pawn', 'pawn', 'gote') },
    ]);
    const table: MaterialValueTable = {
      unpromoted: { pawn: 1, lance: 2, knight: 3, silver: 5, gold: 6, bishop: 7, rook: 11, king: 0 },
      promoted: { pawn: 12, lance: 13, knight: 14, silver: 15, bishop: 16, rook: 17 },
    };
    const expected = evaluateMaterial(state, 'sente', table) +
      evaluatePieceSquarePosition(state, 'sente') +
      evaluateKingSafety(state, 'sente') +
      evaluateUndefendedPieceSafety(state, 'sente', table);

    expect(evaluateSearchPosition(state, 'sente', table)).toBe(expected);
    expect(analyzeAlphaBetaSearch(state, 0, table).selectedEvaluation).toBe(expected);
  });

  it('玉が欠けた人工局面では玉安全度を中立のまま合成する', () => {
    const state = createState([
      { row: 8, col: 4, piece: piece('sente-king', 'king', 'sente') },
      { row: 7, col: 3, piece: piece('gote-pawn', 'pawn', 'gote') },
    ]);
    const evaluation = materialOnlyEvaluation({
      unpromoted: { pawn: 1, lance: 2, knight: 3, silver: 5, gold: 6, bishop: 7, rook: 11, king: 0 },
      promoted: { pawn: 12, lance: 13, knight: 14, silver: 15, bishop: 16, rook: 17 },
    });

    expect(evaluateKingSafety(state, 'sente')).toBe(0);
    expect(evaluateSearchPosition(state, 'sente', evaluation)).toBe(
      evaluateMaterial(state, 'sente', evaluation.materialValueTable) +
      evaluateUndefendedPieceSafety(state, 'sente', evaluation.materialValueTable)
    );
  });

  it.each([
    [{ winner: 'sente', loser: 'gote', endReason: 'checkmate' } satisfies GameResult, Number.POSITIVE_INFINITY],
    [{ winner: 'gote', loser: 'sente', endReason: 'resignation' } satisfies GameResult, Number.NEGATIVE_INFINITY],
    [{ winner: 'gote', loser: 'sente', endReason: 'foul_loss', foulReason: 'nifu' } satisfies GameResult, Number.NEGATIVE_INFINITY],
  ])('勝敗理由にかかわらず勝敗を有限の駒得より優先する', (result, expected) => {
    const state = createState([
      { row: 4, col: 4, piece: piece('sente-material', 'rook', 'sente') },
    ], [], [], 'sente', { status: 'ended', result });

    expect(evaluateSearchPosition(state, 'sente')).toBe(expected);
    expect(evaluateSearchPosition(state, 'gote')).toBe(-expected);
  });

  it.each([
    { winner: null, loser: null, endReason: 'repetition' },
    { winner: null, loser: null, endReason: 'five_hundred_move_jishogi' },
    { winner: null, loser: null, endReason: 'entering_king_draw' },
  ] as const satisfies readonly GameResult[])('勝者のない$endReasonを引き分けとして評価する', (result) => {
    const state = createState([], [], [], 'sente', { status: 'ended', result });
    expect(evaluateSearchPosition(state, 'sente')).toBe(0);
    expect(evaluateSearchPosition(state, 'gote')).toBe(0);
  });

  it('終局状態とresultの矛盾を通常の駒得として扱わず、入力も変更しない', () => {
    const state = createState([{ row: 4, col: 4, piece: piece('rook', 'rook', 'sente') }]);
    const snapshot = JSON.stringify(state);

    expect(() => evaluateSearchPosition({ ...state, status: 'ended', result: null }, 'sente')).toThrow(/result/);
    expect(() => evaluateSearchPosition({ ...state, result: { winner: 'sente', loser: 'gote', endReason: 'checkmate' } }, 'sente')).toThrow(/Non-ended/);
    expect(JSON.stringify(state)).toBe(snapshot);
  });
});

describe('2手読みミニマックスAI', () => {
  it('全root候補の最小評価が-∞でも固定順の最初の合法手を返す', () => {
    const state = forcedLossAfterEveryRootActionState();
    const snapshot = JSON.stringify(state);
    const rootActions = getLegalActions(state);

    expect(rootActions).toHaveLength(1);
    const worstEvaluations = rootActions.map((rootAction) => {
      const afterRootAction = execute(state, rootAction);
      const replies = getLegalActions(afterRootAction);
      expect(replies.length).toBeGreaterThan(0);
      return Math.min(...replies.map((reply) =>
        evaluateSearchPosition(execute(afterRootAction, reply), state.turn)
      ));
    });

    expect(worstEvaluations).toEqual([Number.NEGATIVE_INFINITY]);
    expect(selectBestTwoPlyMinimaxAction(state)).toEqual(rootActions[0]);
    expect(JSON.stringify(state)).toBe(snapshot);
    expect(selectBestTwoPlyMinimaxAction({
      ...state,
      status: 'ended',
      result: { winner: null, loser: null, endReason: 'repetition' },
    })).toBeNull();
  });

  it('目先の駒得後の取り返しを読んで、1手読みAIとは異なる安全な手を選ぶ', () => {
    const state = recaptureTrapState();
    const evaluation = materialOnlyEvaluation({
      unpromoted: { pawn: 100, lance: 300, knight: 300, silver: 400, gold: 500, bishop: 800, rook: 1000, king: 0 },
      promoted: { pawn: 500, lance: 500, knight: 500, silver: 500, bishop: 1000, rook: 1200 },
    });
    const onePly = selectBestMaterialAction(state, 'sente', evaluation);
    const twoPly = selectBestTwoPlyMinimaxAction(state, evaluation);

    expect(onePly).toMatchObject({ kind: 'move', from: { row: 4, col: 4 }, to: { row: 4, col: 5 } });
    expect(twoPly).toMatchObject({ kind: 'move', from: { row: 4, col: 4 }, to: { row: 4, col: 0 } });
    if (!onePly || !twoPly) return;

    const afterTemptingCapture = execute(state, onePly);
    const recapture = findMove(getLegalActions(afterTemptingCapture), { row: 4, col: 6 }, { row: 4, col: 5 });
    const afterRecapture = execute(afterTemptingCapture, recapture);
    const afterSafeMove = execute(state, twoPly);
    const worstSafeReplyEvaluation = Math.min(...getLegalActions(afterSafeMove).map((reply) =>
      evaluateSearchPosition(execute(afterSafeMove, reply), 'sente', evaluation)
    ));

    expect(evaluateSearchPosition(afterRecapture, 'sente', evaluation)).toBeLessThan(
      worstSafeReplyEvaluation
    );
  });

  it('開始手番をrootPlayerに固定し、後手でも同じ最小化応手を読む', () => {
    const state = recaptureTrapState('gote');
    const selected = selectBestTwoPlyMinimaxAction(state);

    expect(selected).toMatchObject({ kind: 'move', from: { row: 4, col: 4 } });
    expect(selected).not.toMatchObject({ kind: 'move', to: { row: 4, col: 5 } });
    if (!selected) return;
    const afterRootAction = execute(state, selected);
    expect(afterRootAction.turn).toBe('sente');
    expect(evaluateSearchPosition(afterRootAction, 'gote')).toBe(
      -evaluateSearchPosition(afterRootAction, 'sente')
    );
  });

  it('詰みになる最初の手を有限の駒得候補より優先する', () => {
    const state = createState([
      { row: 8, col: 4, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 4, piece: piece('gote-king', 'king', 'gote') },
      { row: 2, col: 4, piece: piece('mating-rook', 'rook', 'sente') },
      { row: 1, col: 4, piece: piece('captured-silver', 'silver', 'gote') },
      { row: 2, col: 3, piece: piece('rook-defender', 'gold', 'sente') },
      { row: 2, col: 1, piece: piece('left-escape-guard', 'bishop', 'sente') },
      { row: 2, col: 7, piece: piece('right-escape-guard', 'bishop', 'sente') },
    ]);
    const selected = selectBestTwoPlyMinimaxAction(state);

    if (!selected) return;
    const afterMate = execute(state, selected);
    expect(afterMate.status).toBe('ended');
    expect(evaluateSearchPosition(afterMate, 'sente')).toBe(Number.POSITIVE_INFINITY);
  });

  it('カスタム評価表、同点の固定順、空候補、入力局面の非破壊を保つ', () => {
    const simpleCapture = createState([
      { row: 8, col: 8, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 8, piece: piece('gote-king', 'king', 'gote') },
      { row: 4, col: 4, piece: piece('sente-rook', 'rook', 'sente') },
      { row: 3, col: 4, piece: piece('gote-pawn', 'pawn', 'gote') },
      { row: 4, col: 5, piece: piece('gote-silver', 'silver', 'gote') },
    ]);
    const pawnFavoredTable: MaterialValueTable = {
      unpromoted: { pawn: 10000, lance: 300, knight: 300, silver: 1, gold: 500, bishop: 800, rook: 1, king: 0 },
      promoted: { pawn: 500, lance: 500, knight: 500, silver: 500, bishop: 1000, rook: 1200 },
    };
    const tieState = createState([
      { row: 8, col: 8, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 8, piece: piece('gote-king', 'king', 'gote') },
    ]);
    const snapshot = JSON.stringify(simpleCapture);

    expect(selectBestTwoPlyMinimaxAction(simpleCapture, pawnFavoredTable)).toMatchObject({
      kind: 'move', from: { row: 4, col: 4 }, to: { row: 3, col: 4 },
    });
    expect(selectBestTwoPlyMinimaxAction(tieState)).toEqual(getLegalActions(tieState)[0]);
    expect(selectBestTwoPlyMinimaxAction({ ...tieState, status: 'ended', result: { winner: null, loser: null, endReason: 'repetition' } })).toBeNull();
    expect(JSON.stringify(simpleCapture)).toBe(snapshot);
  });
});

describe('2手読みミニマックスAIの探索計測', () => {
  it('既存の選択手を保ったまま、候補評価と決定的な調査局面数を集約する', () => {
    const state = recaptureTrapState();
    const snapshot = JSON.stringify(state);
    const rootActions = getLegalActions(state);
    const expectedVisitedPositionCount = rootActions.reduce((count, action) => {
      const afterRootAction = execute(state, action);
      return count + 1 + (afterRootAction.status === 'ended'
        ? 0
        : getLegalActions(afterRootAction).length);
    }, 0);

    const result = analyzeTwoPlyMinimaxSearch(state);
    const selectedCandidate = result.topCandidates.find((candidate) =>
      JSON.stringify(candidate.action) === JSON.stringify(result.selectedAction)
    );

    expect(result.selectedAction).toEqual(selectBestTwoPlyMinimaxAction(state));
    expect(result.rootLegalActionCount).toBe(rootActions.length);
    expect(result.visitedPositionCount).toBe(expectedVisitedPositionCount);
    expect(result.depth).toBe(2);
    expect(result.selectedEvaluation).toBe(selectedCandidate?.evaluation);
    expect(result.elapsedMilliseconds).toBeGreaterThanOrEqual(0);
    expect(JSON.stringify(state)).toBe(snapshot);
  });

  it('上位候補をAI視点の降順かつ固定順の同点処理で最大3件にする', () => {
    const state = recaptureTrapState();
    const result = analyzeTwoPlyMinimaxSearch(state);

    expect(result.topCandidates).toHaveLength(Math.min(3, getLegalActions(state).length));
    for (let index = 1; index < result.topCandidates.length; index += 1) {
      expect(result.topCandidates[index - 1].evaluation).toBeGreaterThanOrEqual(
        result.topCandidates[index].evaluation
      );
    }

    const tieState = createState([
      { row: 8, col: 8, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 8, piece: piece('gote-king', 'king', 'gote') },
    ]);
    const tieResult = analyzeTwoPlyMinimaxSearch(tieState);
    expect(tieResult.selectedAction).toEqual(getLegalActions(tieState)[0]);
    expect(tieResult.topCandidates[0]?.action).toEqual(getLegalActions(tieState)[0]);
  });

  it('後手でも評価と候補順をroot AI視点で返す', () => {
    const state = recaptureTrapState('gote');
    const result = analyzeTwoPlyMinimaxSearch(state);
    if (!result.selectedAction) throw new Error('Expected a legal Gote action.');
    const afterSelectedAction = execute(state, result.selectedAction);
    const expectedGotePerspectiveEvaluation = Math.min(...getLegalActions(afterSelectedAction).map((reply) =>
      evaluateSearchPosition(execute(afterSelectedAction, reply), 'gote')
    ));

    expect(result.selectedAction).toEqual(selectBestTwoPlyMinimaxAction(state));
    expect(result.selectedEvaluation).toBe(expectedGotePerspectiveEvaluation);
    for (let index = 1; index < result.topCandidates.length; index += 1) {
      expect(result.topCandidates[index - 1].evaluation).toBeGreaterThanOrEqual(
        result.topCandidates[index].evaluation
      );
    }
  });

  it('合法手が3件未満でも結果を返し、終局局面では既存どおり手を選ばない', () => {
    const forcedLoss = forcedLossAfterEveryRootActionState();
    const result = analyzeTwoPlyMinimaxSearch(forcedLoss);
    const ended = {
      ...forcedLoss,
      status: 'ended' as const,
      result: { winner: null, loser: null, endReason: 'repetition' } satisfies GameResult,
    };

    expect(result.rootLegalActionCount).toBe(1);
    expect(result.topCandidates).toHaveLength(1);
    expect(result.selectedAction).toEqual(getLegalActions(forcedLoss)[0]);
    expect(result.evaluationBreakdown).toMatchObject({ total: -Infinity, terminal: 'loss' });
    expect(analyzeTwoPlyMinimaxSearch(ended)).toMatchObject({
      selectedAction: null,
      selectedEvaluation: null,
      evaluationBreakdown: null,
      rootLegalActionCount: 0,
      visitedPositionCount: 0,
      topCandidates: [],
    });
  });
});

describe('2手読みαβ枝刈り探索', () => {
  it('通常局面で既存ミニマックスと選択手・選択評価値を一致させ、入力局面を変えない', () => {
    const state = recaptureTrapState();
    const snapshot = JSON.stringify(state);
    const minimax = analyzeTwoPlyMinimaxSearch(state);
    const alphaBeta = analyzeTwoPlyAlphaBetaSearch(state);

    expect(alphaBeta.selectedAction).toEqual(minimax.selectedAction);
    expect(alphaBeta.selectedEvaluation).toBe(minimax.selectedEvaluation);
    expect(selectBestTwoPlyAlphaBetaAction(state)).toEqual(selectBestTwoPlyMinimaxAction(state));
    expect(alphaBeta.rootLegalActionCount).toBe(getLegalActions(state).length);
    expect(alphaBeta.depth).toBe(2);
    expect(JSON.stringify(state)).toBe(snapshot);
  });

  it('先手・後手とも開始時のroot AI視点を固定し、カスタム駒価値表でもミニマックスと一致する', () => {
    const table: MaterialValueTable = {
      unpromoted: { pawn: 13, lance: 2, knight: 3, silver: 17, gold: 5, bishop: 7, rook: 19, king: 0 },
      promoted: { pawn: 23, lance: 29, knight: 31, silver: 37, bishop: 41, rook: 43 },
    };

    for (const turn of ['sente', 'gote'] as const) {
      const state = recaptureTrapState(turn);
      const minimax = analyzeTwoPlyMinimaxSearch(state, table);
      const alphaBeta = analyzeTwoPlyAlphaBetaSearch(state, table);

      expect(alphaBeta.selectedAction).toEqual(minimax.selectedAction);
      expect(alphaBeta.selectedEvaluation).toBe(minimax.selectedEvaluation);
      if (!alphaBeta.selectedAction) throw new Error('Expected a legal root action.');
      const afterRootAction = execute(state, alphaBeta.selectedAction);
      const replies = getLegalActions(afterRootAction);
      expect(alphaBeta.selectedEvaluation).toBe(Math.min(...replies.map((reply) =>
        evaluateSearchPosition(execute(afterRootAction, reply), turn, table)
      )));
    }
  });

  it('同点では固定順の先頭を選び、全候補が-∞でも最初の合法手を返す', () => {
    const tieState = createState([
      { row: 8, col: 8, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 8, piece: piece('gote-king', 'king', 'gote') },
    ]);
    const forcedLoss = forcedLossAfterEveryRootActionState();

    expect(selectBestTwoPlyAlphaBetaAction(tieState)).toEqual(getLegalActions(tieState)[0]);
    expect(selectBestTwoPlyAlphaBetaAction(forcedLoss)).toEqual(getLegalActions(forcedLoss)[0]);
    expect(analyzeTwoPlyAlphaBetaSearch(forcedLoss).selectedEvaluation).toBe(Number.NEGATIVE_INFINITY);
  });

  it('詰みの+∞を有限の駒得候補より優先して、ミニマックスと一致する', () => {
    const state = createState([
      { row: 8, col: 4, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 4, piece: piece('gote-king', 'king', 'gote') },
      { row: 2, col: 4, piece: piece('mating-rook', 'rook', 'sente') },
      { row: 1, col: 4, piece: piece('captured-silver', 'silver', 'gote') },
      { row: 2, col: 3, piece: piece('rook-defender', 'gold', 'sente') },
      { row: 2, col: 1, piece: piece('left-escape-guard', 'bishop', 'sente') },
      { row: 2, col: 7, piece: piece('right-escape-guard', 'bishop', 'sente') },
    ]);
    const minimax = analyzeTwoPlyMinimaxSearch(state);
    const alphaBeta = analyzeTwoPlyAlphaBetaSearch(state);

    expect(alphaBeta.selectedAction).toEqual(minimax.selectedAction);
    expect(alphaBeta.selectedEvaluation).toBe(Number.POSITIVE_INFINITY);
    if (!alphaBeta.selectedAction) throw new Error('Expected a mating action.');
    expect(evaluateSearchPosition(execute(state, alphaBeta.selectedAction), 'sente')).toBe(Number.POSITIVE_INFINITY);
  });

  it('終局済み局面では手を選ばず、枝刈り計測はすべて0にする', () => {
    const ended = {
      ...forcedLossAfterEveryRootActionState(),
      status: 'ended' as const,
      result: { winner: null, loser: null, endReason: 'repetition' } satisfies GameResult,
    };

    expect(analyzeTwoPlyAlphaBetaSearch(ended, undefined, () => 50)).toMatchObject({
      selectedAction: null,
      selectedEvaluation: null,
      rootLegalActionCount: 0,
      visitedPositionCount: 0,
      depth: 2,
      elapsedMilliseconds: 0,
      prunedRootCandidateCount: 0,
      skippedOpponentReplyCount: 0,
    });
  });

  it('打ち切ったroot候補数と未実行応手数を、実際に省略した探索局面として数える', () => {
    const state = createState([
      { row: 8, col: 8, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 8, piece: piece('gote-king', 'king', 'gote') },
    ]);
    const minimax = analyzeTwoPlyMinimaxSearch(state);
    const alphaBeta = analyzeTwoPlyAlphaBetaSearch(state);

    // The first root action establishes alpha=0. Later tied candidates have
    // more legal replies, so their first evaluated reply proves they cannot
    // displace the fixed-order winner and leaves replies unexecuted.
    expect(alphaBeta.prunedRootCandidateCount).toBeGreaterThanOrEqual(1);
    expect(alphaBeta.skippedOpponentReplyCount).toBeGreaterThan(0);
    expect(alphaBeta.visitedPositionCount).toBeLessThan(minimax.visitedPositionCount);
    expect(alphaBeta.visitedPositionCount + alphaBeta.skippedOpponentReplyCount).toBe(
      minimax.visitedPositionCount
    );
  });

  it('打ち切りが発生しない終局局面では、打ち切り計測を0のまま保つ', () => {
    const ended = {
      ...forcedLossAfterEveryRootActionState(),
      status: 'ended' as const,
      result: { winner: null, loser: null, endReason: 'entering_king_draw' } satisfies GameResult,
    };
    const result = analyzeTwoPlyAlphaBetaSearch(ended);

    expect(result.prunedRootCandidateCount).toBe(0);
    expect(result.skippedOpponentReplyCount).toBe(0);
  });

  it('注入時計は経過時間だけを測り、決定的な探索結果を変えない', () => {
    const state = recaptureTrapState();
    const readings = [100, 137];
    const clock = () => readings.shift() ?? 137;
    const measured = analyzeTwoPlyAlphaBetaSearch(state, undefined, clock);
    const baseline = analyzeTwoPlyAlphaBetaSearch(state, undefined, () => 0);

    expect(measured.elapsedMilliseconds).toBe(37);
    expect(measured.selectedAction).toEqual(baseline.selectedAction);
    expect(measured.selectedEvaluation).toBe(baseline.selectedEvaluation);
    expect(measured.visitedPositionCount).toBe(baseline.visitedPositionCount);
    expect(measured.prunedRootCandidateCount).toBe(baseline.prunedRootCandidateCount);
    expect(measured.skippedOpponentReplyCount).toBe(baseline.skippedOpponentReplyCount);
  });
});

describe('再帰型αβ枝刈り探索', () => {
  it('駒得が同じ制御局面では、1手読みとαβが位置的に高い歩の前進を選び、参照ミニマックスと一致する', () => {
    const state = createState([
      { row: 8, col: 8, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 0, piece: piece('gote-king', 'king', 'gote') },
      { row: 6, col: 4, piece: piece('sente-pawn', 'pawn', 'sente') },
    ]);
    const expected = findMove(getLegalActions(state), { row: 6, col: 4 }, { row: 5, col: 4 });
    const reference = analyzeUnprunedMinimaxForTest(state, 1);
    const alphaBeta = analyzeAlphaBetaSearch(state, 1);

    expect(selectBestMaterialAction(state, 'sente')).toEqual(expected);
    expect(alphaBeta.selectedAction).toEqual(expected);
    expect(alphaBeta.selectedAction).toEqual(reference.selectedAction);
    expect(alphaBeta.selectedEvaluation).toBe(reference.selectedEvaluation);
    expect(alphaBeta.selectedEvaluation).toBe(
      evaluateSearchPosition(execute(state, expected), 'sente')
    );
    expect(alphaBeta.principalVariation).toEqual([expected]);
    replayPrincipalVariation(state, alphaBeta.principalVariation);
  });

  it('深さ2は旧2 plyミニマックスと互換ラッパーの選択手・評価値・統計を保つ', () => {
    const state = recaptureTrapState();
    const snapshot = JSON.stringify(state);
    const minimax = analyzeTwoPlyMinimaxSearch(state);
    const legacyTwoPly = analyzeTwoPlyAlphaBetaSearch(state);
    const recursive = analyzeAlphaBetaSearch(state, 2);

    expect(recursive.selectedAction).toEqual(minimax.selectedAction);
    expect(recursive.selectedEvaluation).toBe(minimax.selectedEvaluation);
    expect(recursive.selectedAction).toEqual(legacyTwoPly.selectedAction);
    expect(recursive.selectedEvaluation).toBe(legacyTwoPly.selectedEvaluation);
    expect(recursive.visitedPositionCount).toBe(legacyTwoPly.visitedPositionCount);
    expect(recursive.cutoffCount).toBe(legacyTwoPly.prunedRootCandidateCount);
    expect(recursive.skippedActionCount).toBe(legacyTwoPly.skippedOpponentReplyCount);
    expect(selectBestAlphaBetaAction(state, 2)).toEqual(selectBestTwoPlyAlphaBetaAction(state));
    expect(JSON.stringify(state)).toBe(snapshot);
  });

  it('深さ0は局面だけを評価して子局面を生成せず、深さ1/2/3はrootを含むply数で読む', () => {
    const state = recaptureTrapState();
    const depth0 = analyzeAlphaBetaSearch(state, 0);
    const depth1 = analyzeAlphaBetaSearch(state, 1);
    const depth2 = analyzeAlphaBetaSearch(state, 2);
    const depth3 = analyzeAlphaBetaSearch(state, 3);

    expect(depth0).toMatchObject({
      selectedAction: null,
      selectedEvaluation: evaluateSearchPosition(state, state.turn),
      rootLegalActionCount: 0,
      visitedPositionCount: 0,
      cutoffCount: 0,
      skippedActionCount: 0,
    });
    // depth 1 generates root successors only. The recursive call receives
    // depth - 1, making depth 2 root/opponent and depth 3 root/opponent/root.
    expect(depth1.visitedPositionCount).toBe(getLegalActions(state).length);
    expect(depth2.visitedPositionCount).toBeGreaterThan(depth1.visitedPositionCount);
    expect(depth3.visitedPositionCount).toBeGreaterThan(depth2.visitedPositionCount);
    expect([depth1.depth, depth2.depth, depth3.depth]).toEqual([1, 2, 3]);
  });

  it('深さ3は合法手と探索統計を返し、入力局面を破壊せず決定的に完了する', () => {
    const state = recaptureTrapState();
    const snapshot = JSON.stringify(state);
    const first = analyzeAlphaBetaSearch(state, 3);
    const second = analyzeAlphaBetaSearch(state, 3);
    const rootActions = getLegalActions(state);

    expect(first.selectedAction).not.toBeNull();
    expect(rootActions).toContainEqual(first.selectedAction);
    expect(first.selectedAction).toEqual(second.selectedAction);
    expect(first.selectedEvaluation).toBe(second.selectedEvaluation);
    expect(first.visitedPositionCount).toBeGreaterThan(0);
    expect(first.cutoffCount).toBeGreaterThanOrEqual(0);
    expect(first.skippedActionCount).toBeGreaterThanOrEqual(0);
    expect(JSON.stringify(state)).toBe(snapshot);
  });

  it('alpha >= betaのカットオフは結果を変えず、深さ1ではカットオフなしでも正しく探索する', () => {
    const tieState = createState([
      { row: 8, col: 8, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 8, piece: piece('gote-king', 'king', 'gote') },
    ]);
    const depth1 = analyzeAlphaBetaSearch(tieState, 1);
    const depth2 = analyzeAlphaBetaSearch(tieState, 2);
    const minimax = analyzeTwoPlyMinimaxSearch(tieState);

    expect(depth1.cutoffCount).toBe(0);
    expect(depth1.skippedActionCount).toBe(0);
    expect(depth1.selectedAction).toEqual(getLegalActions(tieState)[0]);
    expect(depth2.cutoffCount).toBeGreaterThanOrEqual(1);
    expect(depth2.skippedActionCount).toBeGreaterThan(0);
    expect(depth2.selectedAction).toEqual(minimax.selectedAction);
    expect(depth2.selectedEvaluation).toBe(minimax.selectedEvaluation);
    expect(depth2.visitedPositionCount).toBeLessThanOrEqual(minimax.visitedPositionCount);
  });

  it('終局・合法手なし局面では例外や無限再帰を起こさず、探索統計は探索ごとに初期化する', () => {
    const ended = {
      ...forcedLossAfterEveryRootActionState(),
      status: 'ended' as const,
      result: { winner: null, loser: null, endReason: 'repetition' } satisfies GameResult,
    };
    const active = recaptureTrapState();
    const first = analyzeAlphaBetaSearch(active, 2);
    const second = analyzeAlphaBetaSearch(active, 2);

    expect(() => analyzeAlphaBetaSearch(ended, 3)).not.toThrow();
    expect(analyzeAlphaBetaSearch(ended, 3)).toMatchObject({
      selectedAction: null,
      selectedEvaluation: null,
      rootLegalActionCount: 0,
      visitedPositionCount: 0,
      cutoffCount: 0,
      skippedActionCount: 0,
    });
    expect(second.visitedPositionCount).toBe(first.visitedPositionCount);
    expect(second.cutoffCount).toBe(first.cutoffCount);
    expect(second.skippedActionCount).toBe(first.skippedActionCount);
  });

  it('既定の2 ply APIは深さ2のままで、無効な深さは明示的に拒否する', () => {
    const state = recaptureTrapState();
    const defaultDepthResult = analyzeTwoPlyAlphaBetaSearch(state);

    expect(TWO_PLY_ALPHA_BETA_SEARCH_DEPTH).toBe(2);
    expect(defaultDepthResult.depth).toBe(2);
    expect(defaultDepthResult.selectedAction).toEqual(analyzeAlphaBetaSearch(state, 2).selectedAction);
    expect(() => analyzeAlphaBetaSearch(state, -1)).toThrow(/non-negative integer/);
    expect(() => analyzeAlphaBetaSearch(state, 1.5)).toThrow(/non-negative integer/);
  });

  it('深さ3は最大化→最小化→最大化で3 ply先を評価し、枝刈りなし参照探索と選択・評価が一致する', () => {
    const state = recaptureTrapState();
    const reference = analyzeUnprunedMinimaxForTest(state, 3);
    const result = analyzeAlphaBetaSearch(state, 3);

    expect(reference.deepestEvaluatedPly).toBe(3);
    expect(result.depth).toBe(3);
    expect(result.selectedAction).toEqual(reference.selectedAction);
    expect(result.selectedEvaluation).toBe(reference.selectedEvaluation);
    expect(result.selectedAction).toMatchObject({
      kind: 'move', from: { row: 4, col: 4 }, to: { row: 8, col: 4 },
    });
    expect(result.visitedPositionCount).toBeLessThanOrEqual(reference.visitedPositionCount);
    expect(result.cutoffCount).toBeGreaterThan(0);
  });

  it('深さ3の途中で詰みへ到達した枝は、それ以上の子局面を生成せず既存の終局評価を返す', () => {
    const state = createState([
      { row: 8, col: 4, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 4, piece: piece('gote-king', 'king', 'gote') },
      { row: 2, col: 4, piece: piece('mating-rook', 'rook', 'sente') },
      { row: 1, col: 4, piece: piece('captured-silver', 'silver', 'gote') },
      { row: 2, col: 3, piece: piece('rook-defender', 'gold', 'sente') },
      { row: 2, col: 1, piece: piece('left-escape-guard', 'bishop', 'sente') },
      { row: 2, col: 7, piece: piece('right-escape-guard', 'bishop', 'sente') },
    ]);
    const reference = analyzeUnprunedMinimaxForTest(state, 3);
    const result = analyzeAlphaBetaSearch(state, 3);

    expect(result.selectedAction).toEqual(reference.selectedAction);
    expect(result.selectedEvaluation).toBe(Number.POSITIVE_INFINITY);
    if (!result.selectedAction) throw new Error('Expected a mating action.');
    const afterMate = execute(state, result.selectedAction);
    expect(afterMate.status).toBe('ended');
    expect(getLegalActions(afterMate)).toEqual([]);
    expect(reference.terminalLeafCount).toBeGreaterThan(0);
    expect(result.visitedPositionCount).toBeLessThanOrEqual(reference.visitedPositionCount);
  });

  it('深さ2と深さ3の統計を同じ定義で比較でき、深さ3の同点でも固定順を保つ', () => {
    const state = recaptureTrapState();
    const depth2 = analyzeAlphaBetaSearch(state, 2);
    const depth3 = analyzeAlphaBetaSearch(state, 3);
    const tieState = createState([
      { row: 8, col: 8, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 8, piece: piece('gote-king', 'king', 'gote') },
    ]);
    const tieDepth3 = analyzeAlphaBetaSearch(tieState, 3);

    expect(depth2.depth).toBe(2);
    expect(depth3.depth).toBe(3);
    expect(depth3.visitedPositionCount).toBeGreaterThan(depth2.visitedPositionCount);
    expect(depth2.cutoffCount).toBeGreaterThanOrEqual(0);
    expect(depth3.cutoffCount).toBeGreaterThanOrEqual(0);
    expect(tieDepth3.selectedAction).toEqual(getLegalActions(tieState)[0]);
  });
});

describe('再帰型αβ探索の主変化', () => {
  it('最大化ノードの全探索済み候補が-∞でも、最初の合法候補をPVへ採用する', () => {
    const state = maximizingNegativeInfinityPrincipalVariationState();
    const snapshot = JSON.stringify(state);
    const rootActions = getLegalActions(state);
    const rootActionsSnapshot = [...rootActions];
    const expectedRootAction = findMove(rootActions, { row: 6, col: 3 }, { row: 5, col: 3 });
    const afterRootAction = execute(state, expectedRootAction);
    const expectedGoteReply = findMove(getLegalActions(afterRootAction), { row: 4, col: 4 }, { row: 5, col: 3 });
    const maximizingNode = execute(afterRootAction, expectedGoteReply);
    const maximizingActions = getLegalActions(maximizingNode);
    const expectedMaximizingAction = findMove(maximizingActions, { row: 6, col: 4 }, { row: 5, col: 3 });

    expect(rootActions[0]).toEqual(expectedRootAction);
    expect(getLegalActions(afterRootAction)).toEqual([expectedGoteReply]);
    expect(maximizingNode.turn).toBe(state.turn);
    expect(maximizingNode.status).not.toBe('ended');
    expect(maximizingActions).toEqual([expectedMaximizingAction]);
    expect(maximizingActions.map((action) =>
      evaluateSearchPosition(execute(maximizingNode, action), state.turn)
    )).toEqual([Number.NEGATIVE_INFINITY]);
    const terminal = execute(maximizingNode, expectedMaximizingAction);
    expect(terminal).toMatchObject({
      status: 'ended',
      result: { winner: 'gote', loser: 'sente', endReason: 'foul_loss' },
    });
    expect(evaluateSearchPosition(terminal, state.turn)).toBe(Number.NEGATIVE_INFINITY);

    const result = analyzeAlphaBetaSearch(state, 3);

    expect(result.selectedAction).toEqual(expectedRootAction);
    expect(result.selectedEvaluation).toBe(Number.NEGATIVE_INFINITY);
    expect(result.principalVariation).toEqual([
      expectedRootAction,
      expectedGoteReply,
      expectedMaximizingAction,
    ]);
    expect(result.principalVariation).toHaveLength(3);
    expect(result.principalVariation.length).toBeLessThanOrEqual(result.depth);
    expect(areLegalActionsEqual(result.principalVariation[0], result.selectedAction!)).toBe(true);
    expect(replayPrincipalVariation(state, result.principalVariation)).toMatchObject({ status: 'ended' });
    expect(rootActions).toEqual(rootActionsSnapshot);
    expect(JSON.stringify(state)).toBe(snapshot);
  });

  it('最小化ノードの全探索済み候補が+∞でも、最初の合法応手を含むPVを返す', () => {
    const state = minimizingPositiveInfinityPrincipalVariationState();
    const snapshot = JSON.stringify(state);
    const expectedRootAction = findMove(getLegalActions(state), { row: 3, col: 0 }, { row: 2, col: 0 });
    const afterRootAction = execute(state, expectedRootAction);
    const expectedReply = findMove(getLegalActions(afterRootAction), { row: 0, col: 0 }, { row: 2, col: 0 });

    expect(getLegalActions(afterRootAction)).toEqual([expectedReply]);
    const terminal = execute(afterRootAction, expectedReply);
    expect(terminal).toMatchObject({
      status: 'ended',
      result: { winner: 'sente', loser: 'gote', endReason: 'foul_loss' },
    });
    expect(evaluateSearchPosition(terminal, state.turn)).toBe(Number.POSITIVE_INFINITY);

    const result = analyzeAlphaBetaSearch(state, 2);

    expect(result.selectedAction).toEqual(expectedRootAction);
    expect(result.selectedEvaluation).toBe(Number.POSITIVE_INFINITY);
    expect(result.principalVariation).toEqual([expectedRootAction, expectedReply]);
    expect(result.principalVariation).toHaveLength(2);
    expect(result.principalVariation.length).toBeLessThanOrEqual(result.depth);
    expect(replayPrincipalVariation(state, result.principalVariation)).toMatchObject({ status: 'ended' });
    expect(JSON.stringify(state)).toBe(snapshot);
  });

  it('深さ1から3で選択手から始まる合法なPVを、不変の入力局面から返す', () => {
    const state = recaptureTrapState();
    const snapshot = JSON.stringify(state);

    for (const depth of [1, 2, 3]) {
      const result = analyzeAlphaBetaSearch(state, depth);
      expect(result.selectedAction).not.toBeNull();
      if (!result.selectedAction) throw new Error('Expected a selected action.');
      expect(result.principalVariation).toHaveLength(depth);
      expect(result.principalVariation.length).toBeLessThanOrEqual(result.depth);
      expect(areLegalActionsEqual(result.principalVariation[0], result.selectedAction)).toBe(true);
      replayPrincipalVariation(state, result.principalVariation);
    }

    expect(JSON.stringify(state)).toBe(snapshot);
  });

  it('終局局面では選択手なしと空のPVを返す', () => {
    const ended = {
      ...forcedLossAfterEveryRootActionState(),
      status: 'ended' as const,
      result: { winner: null, loser: null, endReason: 'repetition' } satisfies GameResult,
    };

    expect(analyzeAlphaBetaSearch(ended, 3)).toMatchObject({
      selectedAction: null,
      principalVariation: [],
    });
  });

  it('反復深化では各完了反復と最上位結果が独立したPVを持つ', () => {
    const state = recaptureTrapState();
    const result = analyzeIterativeDeepeningAlphaBetaSearch(state, 3);

    expect(result.iterations.map((iteration) => iteration.depth)).toEqual([1, 2, 3]);
    for (const iteration of result.iterations) {
      expect(iteration.principalVariation.length).toBeLessThanOrEqual(iteration.depth);
      if (!iteration.selectedAction) throw new Error('Expected an iterative selected action.');
      expect(areLegalActionsEqual(iteration.principalVariation[0], iteration.selectedAction)).toBe(true);
      replayPrincipalVariation(state, iteration.principalVariation);
    }
    expect(result.principalVariation).toEqual(result.iterations[2].principalVariation);
    expect(result.principalVariation).not.toBe(result.iterations[2].principalVariation);

    const timeLimited = analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(state, 3, 1_000, undefined, () => 0);
    expect(timeLimited.principalVariation).toEqual(timeLimited.iterations[2].principalVariation);
    expect(timeLimited.principalVariation).not.toBe(timeLimited.iterations[2].principalVariation);
  });
});

describe('再帰型αβ探索のPV末端評価内訳', () => {
  it('固定深さのscore、PV、内訳を同じ末端局面から返し、入力を変更しない', () => {
    const state = recaptureTrapState();
    const evaluation = materialOnlyEvaluation({
      unpromoted: { pawn: 100, lance: 300, knight: 300, silver: 400, gold: 500, bishop: 800, rook: 1000, king: 0 },
      promoted: { pawn: 500, lance: 500, knight: 500, silver: 500, bishop: 1000, rook: 1200 },
    });
    const stateSnapshot = JSON.stringify(state);
    const evaluationSnapshot = JSON.stringify(evaluation);

    for (const depth of [1, 3]) {
      const result = analyzeAlphaBetaSearch(state, depth, evaluation, () => 0);

      expect(result.selectedEvaluation).toBe(result.evaluationBreakdown.total);
      expectEvaluationBreakdownToMatchPrincipalVariation(state, result, evaluation);
    }

    expect(JSON.stringify(state)).toBe(stateSnapshot);
    expect(JSON.stringify(evaluation)).toBe(evaluationSnapshot);
  });

  it('最大化・最小化の採用候補とαβカットオフ後も、PVと同じ候補の内訳を返す', () => {
    const maximizing = maximizingNegativeInfinityPrincipalVariationState();
    const minimizing = minimizingPositiveInfinityPrincipalVariationState();
    const cutoffState = createState([
      { row: 8, col: 8, piece: piece('sente-king', 'king', 'sente') },
      { row: 0, col: 8, piece: piece('gote-king', 'king', 'gote') },
    ]);
    const maximizingResult = analyzeAlphaBetaSearch(maximizing, 3);
    const minimizingResult = analyzeAlphaBetaSearch(minimizing, 2);
    const cutoffResult = analyzeAlphaBetaSearch(cutoffState, 2);

    expect(maximizingResult.evaluationBreakdown).toMatchObject({
      total: Number.NEGATIVE_INFINITY,
      terminal: 'loss',
    });
    expect(minimizingResult.evaluationBreakdown).toMatchObject({
      total: Number.POSITIVE_INFINITY,
      terminal: 'win',
    });
    expect(cutoffResult.cutoffCount).toBeGreaterThanOrEqual(1);
    expect(cutoffResult.skippedActionCount).toBeGreaterThan(0);

    expectEvaluationBreakdownToMatchPrincipalVariation(maximizing, maximizingResult);
    expectEvaluationBreakdownToMatchPrincipalVariation(minimizing, minimizingResult);
    expectEvaluationBreakdownToMatchPrincipalVariation(cutoffState, cutoffResult);
  });

  it('反復深化と時間制限探索は完了反復だけの対応する内訳を保持する', () => {
    const state = moveOrderingBenefitState();
    const iterative = analyzeIterativeDeepeningAlphaBetaSearch(state, 3, undefined, () => 0);

    for (const iteration of iterative.iterations) {
      expect(iteration.selectedEvaluation).toBe(iteration.evaluationBreakdown.total);
      expectEvaluationBreakdownToMatchPrincipalVariation(state, iteration);
    }
    expect(iterative.evaluationBreakdown).toEqual(iterative.iterations[2].evaluationBreakdown);
    expect(iterative.evaluationBreakdown).not.toBe(iterative.iterations[2].evaluationBreakdown);

    const timedOut = analyzeTimeLimitedIterativeDeepeningAlphaBetaSearch(state, 3, 0, undefined, () => 0);

    expect(timedOut).toMatchObject({ completedDepth: 0, timedOut: true, resultSource: 'fallback',
      selectedAction: getLegalActions(state)[0], selectedEvaluation: null, evaluationBreakdown: null,
      principalVariation: [] });
    expect(timedOut.iterations).toHaveLength(0);
  });

  it('終局の勝ち・負け・引き分けでは空PVでも評価内訳のterminalとtotalを保つ', () => {
    const base = forcedLossAfterEveryRootActionState();
    const cases = [
      {
        state: {
          ...base,
          status: 'ended' as const,
          result: { winner: 'sente' as const, loser: 'gote' as const, endReason: 'checkmate' as const },
        },
        total: Number.POSITIVE_INFINITY,
        terminal: 'win',
      },
      {
        state: {
          ...base,
          status: 'ended' as const,
          result: { winner: 'gote' as const, loser: 'sente' as const, endReason: 'resignation' as const },
        },
        total: Number.NEGATIVE_INFINITY,
        terminal: 'loss',
      },
      {
        state: {
          ...base,
          status: 'ended' as const,
          result: { winner: null, loser: null, endReason: 'repetition' as const },
        },
        total: 0,
        terminal: 'draw',
      },
    ];

    for (const testCase of cases) {
      const result = analyzeAlphaBetaSearch(testCase.state, 3, undefined, () => 0);
      expect(result).toMatchObject({ selectedAction: null, selectedEvaluation: null, principalVariation: [] });
      expect(result.evaluationBreakdown).toMatchObject({ total: testCase.total, terminal: testCase.terminal });
      expectEvaluationBreakdownToMatchPrincipalVariation(testCase.state, result);
    }
  });
});
