export type AppView = 'shogi';
