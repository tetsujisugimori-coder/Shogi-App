/**
 * Deterministic, public enumeration of every currently legal shogi action.
 *
 * This deliberately composes the existing move, promotion, and drop rule APIs
 * rather than owning another copy of the game rules. It is suitable as the
 * common input boundary for local AI, search, and engine adapters.
 */
import {
  BoardState,
  ExecutionMode,
  MovePromotion,
  PieceType,
  Player,
  ProposerType,
} from '../../types/shogi';
import type { ActionValidationDiagnostics, ActionValidationProbe } from './actionValidationDiagnostics';
import { Coordinate } from './coordinates';
import { getLegalDropSquares } from './dropRules';
import { DropExecutionResult, executeDrop } from './drops';
import { MoveExecutionResult, executeMove } from './gameState';
import { getLegalMoves } from './moves';
import { getPromotionStatus } from './promotion';
import { measured, type SearchDiagnostics } from './searchDiagnostics';

export interface LegalMoveAction {
  kind: 'move';
  player: Player;
  from: Coordinate;
  to: Coordinate;
  pieceType: PieceType;
  promotion: MovePromotion;
}

export interface LegalDropAction {
  kind: 'drop';
  player: Player;
  pieceId: string;
  pieceType: PieceType;
  to: Coordinate;
  promotion: 'none';
}

export type LegalAction = LegalMoveAction | LegalDropAction;

export interface ExecuteLegalActionOptions {
  mode?: ExecutionMode;
  proposer?: ProposerType;
  engineName?: string;
}

export type LegalActionExecutionResult = MoveExecutionResult | DropExecutionResult;

/**
 * Stable hand-piece ordering used after all board moves. Keeping this explicit
 * makes generated action lists reproducible across callers.
 */
const DROP_PIECE_TYPE_ORDER = [
  'rook',
  'bishop',
  'gold',
  'silver',
  'knight',
  'lance',
  'pawn',
] as const satisfies readonly Exclude<PieceType, 'king'>[];

function compareCoordinates(left: Coordinate, right: Coordinate): number {
  return left.row - right.row || left.col - right.col;
}

function copyCoordinate(coordinate: Coordinate): Coordinate {
  return { row: coordinate.row, col: coordinate.col };
}

function compareIds(left: string, right: string): number {
  return left < right ? -1 : left > right ? 1 : 0;
}

/**
 * Returns every legal action for the player whose turn it is.
 *
 * Order is part of this API's contract: board moves (source row/column,
 * destination row/column, decline before promote) precede drops. Drops use
 * the fixed piece-type order above and then destination row/column. When a
 * hand contains identical pieces, the lexicographically smallest ID is the
 * representative action because the destinations are otherwise equivalent.
 */
// The second argument records root breakdown only. Internal nodes pass just the
// third argument, keeping generation validation separate from root aggregates.
export function getLegalActions(state: BoardState, diagnostics?: SearchDiagnostics,
  actionValidation: ActionValidationDiagnostics | undefined = diagnostics?.actionValidation ?? undefined): LegalAction[] {
  if (state.status === 'ended') return [];

  const actions: LegalAction[] = [];

  for (let row = 0; row < state.squares.length; row += 1) {
    for (let col = 0; col < state.squares[row].length; col += 1) {
      const piece = state.squares[row][col].piece;
      if (!piece || piece.player !== state.turn) continue;

      const from = { row, col };
      const destinations = measured(diagnostics, 'root-piece-moves', () => getLegalMoves(state.squares, from, state.turn, undefined, actionValidation?.generationBoard))
        .slice()
        .sort(compareCoordinates);

      for (const destination of destinations) {
        const promotionStatus = getPromotionStatus(piece, from, destination);
        const promotions: readonly MovePromotion[] =
          promotionStatus === 'optional'
            ? ['decline', 'promote']
            : promotionStatus === 'required'
              ? ['promote']
              : ['none'];

        for (const promotion of promotions) {
          actions.push({
            kind: 'move',
            player: state.turn,
            from: copyCoordinate(from),
            to: copyCoordinate(destination),
            pieceType: piece.type,
            promotion,
          });
        }
      }
    }
  }

  const currentHand = state.turn === 'sente' ? state.senteHand : state.goteHand;
  for (const pieceType of DROP_PIECE_TYPE_ORDER) {
    const representativePieceId = currentHand
      .filter(
        (piece) =>
          piece.player === state.turn &&
          piece.type === pieceType &&
          !piece.isPromoted
      )
      .map((piece) => piece.id)
      .sort(compareIds)[0];

    if (!representativePieceId) continue;

    const destinations = measured(diagnostics, 'root-hand-drops', () => {
      const began = diagnostics ? diagnostics.now() : 0;
      const squares = getLegalDropSquares(state, representativePieceId, diagnostics, undefined, actionValidation?.generationDrop);
      if (diagnostics) {
        const duration = Math.max(0, diagnostics.now() - began);
        const entry = diagnostics.rootDrops[pieceType];
        entry.calls++;
        entry.milliseconds += duration;
        entry.maxMilliseconds = Math.max(entry.maxMilliseconds, duration);
      }
      return squares;
    })
      .slice()
      .sort(compareCoordinates);
    for (const destination of destinations) {
      actions.push({
        kind: 'drop',
        player: state.turn,
        pieceId: representativePieceId,
        pieceType,
        to: copyCoordinate(destination),
        promotion: 'none',
      });
    }
  }

  return actions;
}

/** Detail-only enumeration. The ordinary and root paths above execute unchanged. */
export function getQuiescenceLegalActionsWithDiagnostics(state: BoardState,
  diagnostics: SearchDiagnostics): LegalAction[] {
  if (state.status === 'ended') return [];
  const actions: LegalAction[] = [];
  for (let row = 0; row < state.squares.length; row += 1) {
    for (let col = 0; col < state.squares[row].length; col += 1) {
      const piece = state.squares[row][col].piece;
      if (!piece || piece.player !== state.turn) continue;
      const from = { row, col };
      diagnostics.qLegalCounts.boardSources++;
      const destinations = diagnostics.measure('q-board-moves', () =>
        getLegalMoves(state.squares, from, state.turn, diagnostics, diagnostics.actionValidation?.generationBoard)).slice().sort(compareCoordinates);
      const before = actions.length;
      for (const destination of destinations) {
        const promotionStatus = getPromotionStatus(piece, from, destination);
        const promotions: readonly MovePromotion[] = promotionStatus === 'optional'
          ? ['decline', 'promote'] : promotionStatus === 'required' ? ['promote'] : ['none'];
        for (const promotion of promotions) {
          actions.push({ kind: 'move', player: state.turn, from: copyCoordinate(from),
            to: copyCoordinate(destination), pieceType: piece.type, promotion });
        }
      }
      diagnostics.qLegalCounts.boardActions += actions.length - before;
    }
  }
  const currentHand = state.turn === 'sente' ? state.senteHand : state.goteHand;
  for (const pieceType of DROP_PIECE_TYPE_ORDER) {
    const representativePieceId = currentHand
      .filter(piece => piece.player === state.turn && piece.type === pieceType && !piece.isPromoted)
      .map(piece => piece.id).sort(compareIds)[0];
    if (!representativePieceId) continue;
    diagnostics.qLegalCounts.dropTypes++;
    const destinations = diagnostics.measure('q-hand-drops', () =>
      getLegalDropSquares(state, representativePieceId, undefined, diagnostics, diagnostics.actionValidation?.generationDrop)).slice().sort(compareCoordinates);
    for (const destination of destinations) {
      actions.push({ kind: 'drop', player: state.turn, pieceId: representativePieceId,
        pieceType, to: copyCoordinate(destination), promotion: 'none' });
    }
    diagnostics.qLegalCounts.dropActions += destinations.length;
  }
  diagnostics.qLegalCounts.actions += actions.length;
  return actions;
}

/** Executes an enumerated action through the existing validated execution APIs. */
export function executeLegalAction(
  state: BoardState,
  action: LegalAction,
  options: ExecuteLegalActionOptions = {},
  diagnostics?: SearchDiagnostics
): LegalActionExecutionResult {
  const probe = action.kind === 'drop' ? diagnostics?.actionValidation?.executionDrop
    : diagnostics?.actionValidation?.executionBoard;
  return probe ? probe.measure('execute-action', () => executeLegalActionValidated(state, action, options, probe))
    : executeLegalActionValidated(state, action, options);
}

function executeLegalActionValidated(state: BoardState, action: LegalAction,
  options: ExecuteLegalActionOptions, probe?: ActionValidationProbe): LegalActionExecutionResult {
  if (action.kind === 'drop') {
    return probe ? probe.measure('execute-api', () => executeDrop(state, action.pieceId, action.to, options, probe))
      : executeDrop(state, action.pieceId, action.to, options);
  }

  if (action.promotion === 'none') {
    return probe ? probe.measure('execute-api', () => executeMove(state, action.from, action.to, options, probe))
      : executeMove(state, action.from, action.to, options);
  }

  const moveOptions = { ...options, promotion: action.promotion };
  return probe ? probe.measure('execute-api', () => executeMove(state, action.from, action.to, moveOptions, probe))
    : executeMove(state, action.from, action.to, moveOptions);
}
